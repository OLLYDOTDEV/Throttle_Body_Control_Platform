/*
 * Community and Technical College License -- for use in teaching and
 * meeting course requirements at community and technical colleges only.
 * Not for government, commercial, university, or other organizational
 * use.
 *
 * File: CONTROL_SYSTEM_V2.c
 *
 * Code generated for Simulink model 'CONTROL_SYSTEM_V2'.
 *
 * Model version                  : 1.11
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Fri Sep  6 13:49:24 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "CONTROL_SYSTEM_V2.h"
#include "rtwtypes.h"
#include "CONTROL_SYSTEM_V2_types.h"
#include "CONTROL_SYSTEM_V2_private.h"
#include <math.h>
#include "rt_nonfinite.h"
#include "zero_crossing_types.h"

/* Block signals (default storage) */
B_CONTROL_SYSTEM_V2_T CONTROL_SYSTEM_V2_B;

/* Continuous states */
X_CONTROL_SYSTEM_V2_T CONTROL_SYSTEM_V2_X;

/* Disabled State Vector */
XDis_CONTROL_SYSTEM_V2_T CONTROL_SYSTEM_V2_XDis;

/* Block states (default storage) */
DW_CONTROL_SYSTEM_V2_T CONTROL_SYSTEM_V2_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_CONTROL_SYSTEM_V2_T CONTROL_SYSTEM_V2_PrevZCX;

/* Real-time model */
static RT_MODEL_CONTROL_SYSTEM_V2_T CONTROL_SYSTEM_V2_M_;
RT_MODEL_CONTROL_SYSTEM_V2_T *const CONTROL_SYSTEM_V2_M = &CONTROL_SYSTEM_V2_M_;

/* Forward declaration for local functions */
static void CONTROL_SYST_SystemCore_release(codertarget_arduinobase_inter_T *obj);

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 5;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  CONTROL_SYSTEM_V2_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  CONTROL_SYSTEM_V2_step();
  CONTROL_SYSTEM_V2_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  CONTROL_SYSTEM_V2_step();
  CONTROL_SYSTEM_V2_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/*
 * System initialize for enable system:
 *    '<S28>/NEGATIVE Edge'
 *    '<S36>/NEGATIVE Edge'
 */
void CONTROL_SYSTE_NEGATIVEEdge_Init(boolean_T *rty_OUT,
  P_NEGATIVEEdge_CONTROL_SYSTEM_T *localP)
{
  /* SystemInitialize for Outport: '<S30>/OUT' */
  *rty_OUT = localP->OUT_Y0;
}

/*
 * Disable for enable system:
 *    '<S28>/NEGATIVE Edge'
 *    '<S36>/NEGATIVE Edge'
 */
void CONTROL_SY_NEGATIVEEdge_Disable(DW_NEGATIVEEdge_CONTROL_SYSTE_T *localDW)
{
  localDW->NEGATIVEEdge_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S28>/NEGATIVE Edge'
 *    '<S36>/NEGATIVE Edge'
 */
void CONTROL_SYSTEM_V2_NEGATIVEEdge(RT_MODEL_CONTROL_SYSTEM_V2_T * const
  CONTROL_SYSTEM_V2_M, real_T rtu_Enable, boolean_T rtu_IN, boolean_T
  rtu_INprevious, boolean_T *rty_OUT, DW_NEGATIVEEdge_CONTROL_SYSTE_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S28>/NEGATIVE Edge' incorporates:
   *  EnablePort: '<S30>/Enable'
   */
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M) && rtsiIsModeUpdateTimeStep
      (&CONTROL_SYSTEM_V2_M->solverInfo)) {
    if (rtu_Enable > 0.0) {
      localDW->NEGATIVEEdge_MODE = true;
    } else if (localDW->NEGATIVEEdge_MODE) {
      CONTROL_SY_NEGATIVEEdge_Disable(localDW);
    }
  }

  if (localDW->NEGATIVEEdge_MODE) {
    /* RelationalOperator: '<S30>/Relational Operator1' */
    *rty_OUT = ((int32_T)rtu_INprevious > (int32_T)rtu_IN);
    if (rtsiIsModeUpdateTimeStep(&CONTROL_SYSTEM_V2_M->solverInfo)) {
      srUpdateBC(localDW->NEGATIVEEdge_SubsysRanBC);
    }
  }

  /* End of Outputs for SubSystem: '<S28>/NEGATIVE Edge' */
}

/*
 * System initialize for enable system:
 *    '<S28>/POSITIVE Edge'
 *    '<S36>/POSITIVE Edge'
 */
void CONTROL_SYSTE_POSITIVEEdge_Init(boolean_T *rty_OUT,
  P_POSITIVEEdge_CONTROL_SYSTEM_T *localP)
{
  /* SystemInitialize for Outport: '<S31>/OUT' */
  *rty_OUT = localP->OUT_Y0;
}

/*
 * Disable for enable system:
 *    '<S28>/POSITIVE Edge'
 *    '<S36>/POSITIVE Edge'
 */
void CONTROL_SY_POSITIVEEdge_Disable(DW_POSITIVEEdge_CONTROL_SYSTE_T *localDW)
{
  localDW->POSITIVEEdge_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S28>/POSITIVE Edge'
 *    '<S36>/POSITIVE Edge'
 */
void CONTROL_SYSTEM_V2_POSITIVEEdge(RT_MODEL_CONTROL_SYSTEM_V2_T * const
  CONTROL_SYSTEM_V2_M, real_T rtu_Enable, boolean_T rtu_IN, boolean_T
  rtu_INprevious, boolean_T *rty_OUT, DW_POSITIVEEdge_CONTROL_SYSTE_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S28>/POSITIVE Edge' incorporates:
   *  EnablePort: '<S31>/Enable'
   */
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M) && rtsiIsModeUpdateTimeStep
      (&CONTROL_SYSTEM_V2_M->solverInfo)) {
    if (rtu_Enable > 0.0) {
      localDW->POSITIVEEdge_MODE = true;
    } else if (localDW->POSITIVEEdge_MODE) {
      CONTROL_SY_POSITIVEEdge_Disable(localDW);
    }
  }

  if (localDW->POSITIVEEdge_MODE) {
    /* RelationalOperator: '<S31>/Relational Operator1' */
    *rty_OUT = ((int32_T)rtu_INprevious < (int32_T)rtu_IN);
    if (rtsiIsModeUpdateTimeStep(&CONTROL_SYSTEM_V2_M->solverInfo)) {
      srUpdateBC(localDW->POSITIVEEdge_SubsysRanBC);
    }
  }

  /* End of Outputs for SubSystem: '<S28>/POSITIVE Edge' */
}

real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

static void CONTROL_SYST_SystemCore_release(codertarget_arduinobase_inter_T *obj)
{
  /* Start for MATLABSystem: '<S9>/PWM' */
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    obj->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_GetHandle(4U);
    MW_PWM_SetDutyCycle(obj->PWMDriverObj.MW_PWM_HANDLE, -0.0);
    obj->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_GetHandle(4U);
    MW_PWM_Close(obj->PWMDriverObj.MW_PWM_HANDLE);
  }

  /* End of Start for MATLABSystem: '<S9>/PWM' */
}

/* Model step function */
void CONTROL_SYSTEM_V2_step(void)
{
  real_T rtb_Clock;
  real_T rtb_Fcn3;
  real_T rtb_FromWs;
  real_T rtb_Sum2_m;
  real_T tmp;
  int32_T rowIdx;
  int8_T rowIdx_tmp_4;
  uint8_T tmp_0;
  boolean_T LogicalOperator1;
  boolean_T c_value;
  boolean_T c_value_0;
  boolean_T c_value_1;
  boolean_T rowIdx_tmp;
  boolean_T rowIdx_tmp_0;
  boolean_T rowIdx_tmp_1;
  boolean_T rowIdx_tmp_2;
  boolean_T rowIdx_tmp_3;
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
    /* set solver stop time */
    rtsiSetSolverStopTime(&CONTROL_SYSTEM_V2_M->solverInfo,
                          ((CONTROL_SYSTEM_V2_M->Timing.clockTick0+1)*
      CONTROL_SYSTEM_V2_M->Timing.stepSize0));
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(CONTROL_SYSTEM_V2_M)) {
    CONTROL_SYSTEM_V2_M->Timing.t[0] = rtsiGetT(&CONTROL_SYSTEM_V2_M->solverInfo);
  }

  /* Reset subsysRan breadcrumbs */
  srClearBC(CONTROL_SYSTEM_V2_DW.TriggeredSubsystem_SubsysRanB_n);

  /* Reset subsysRan breadcrumbs */
  srClearBC(CONTROL_SYSTEM_V2_DW.NEGATIVEEdge.NEGATIVEEdge_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(CONTROL_SYSTEM_V2_DW.POSITIVEEdge.POSITIVEEdge_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(CONTROL_SYSTEM_V2_DW.OFFDelay_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(CONTROL_SYSTEM_V2_DW.TriggeredSubsystem_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(CONTROL_SYSTEM_V2_DW.ONDelay_SubsysRanBC);

  /* Integrator: '<S12>/Integrator1' */
  CONTROL_SYSTEM_V2_B.Integrator1[0] = CONTROL_SYSTEM_V2_X.Integrator1_CSTATE[0];
  CONTROL_SYSTEM_V2_B.Integrator1[1] = CONTROL_SYSTEM_V2_X.Integrator1_CSTATE[1];
  CONTROL_SYSTEM_V2_B.Integrator1[2] = CONTROL_SYSTEM_V2_X.Integrator1_CSTATE[2];
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
  }

  /* Sum: '<S12>/Sum2' incorporates:
   *  Integrator: '<S1>/Integrator'
   */
  rtb_Fcn3 = CONTROL_SYSTEM_V2_X.Integrator_CSTATE -
    CONTROL_SYSTEM_V2_B.Integrator1[0];

  /* Gain: '<S12>/Gain' */
  rtb_FromWs = CONTROL_SYSTEM_V2_B.Integrator1[1];
  rtb_Clock = CONTROL_SYSTEM_V2_B.Integrator1[0];
  rtb_Sum2_m = CONTROL_SYSTEM_V2_B.Integrator1[2];

  /* Sum: '<S12>/Sum1' incorporates:
   *  Gain: '<S12>/Gain'
   *  Gain: '<S12>/Gain2'
   */
  for (rowIdx = 0; rowIdx < 3; rowIdx++) {
    CONTROL_SYSTEM_V2_B.Sum1_j[rowIdx] = ((CONTROL_SYSTEM_V2_P.Gain_Gain[rowIdx
      + 3] * rtb_FromWs + CONTROL_SYSTEM_V2_P.Gain_Gain[rowIdx] * rtb_Clock) +
      CONTROL_SYSTEM_V2_P.Gain_Gain[rowIdx + 6] * rtb_Sum2_m) +
      CONTROL_SYSTEM_V2_P.Gain2_Gain[rowIdx] * rtb_Fcn3;
  }

  /* End of Sum: '<S12>/Sum1' */
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
    /* Fcn: '<S11>/Fcn' incorporates:
     *  Constant: '<S11>/Constant2'
     */
    CONTROL_SYSTEM_V2_B.Fcn = 1.0 / (CONTROL_SYSTEM_V2_P.roa /
      CONTROL_SYSTEM_V2_P.J_aet);
  }

  /* MATLABSystem: '<S2>/MATLAB System' */
  if (CONTROL_SYSTEM_V2_DW.obj.SampleTime !=
      CONTROL_SYSTEM_V2_P.MATLABSystem_SampleTime) {
    CONTROL_SYSTEM_V2_DW.obj.SampleTime =
      CONTROL_SYSTEM_V2_P.MATLABSystem_SampleTime;
  }

  /* MATLABSystem: '<S2>/MATLAB System' */
  /*         %% Define output properties */
  CONTROL_SYSTEM_V2_B.MATLABSystem_o1 = 0.0;

  /* MATLABSystem: '<S2>/MATLAB System' */
  CONTROL_SYSTEM_V2_B.MATLABSystem_o2 = 0.0;

  /* MATLABSystem: '<S2>/MATLAB System' */
  CONTROL_SYSTEM_V2_B.MATLABSystem_o3 = 0.0;

  /* MATLABSystem: '<S2>/MATLAB System' */
  CONTROL_SYSTEM_V2_B.MATLABSystem_o4 = 0.0;
  stepFunctionADS1115_Vread(&CONTROL_SYSTEM_V2_B.MATLABSystem_o1, 1.0,
    &CONTROL_SYSTEM_V2_B.MATLABSystem_o2, 1.0,
    &CONTROL_SYSTEM_V2_B.MATLABSystem_o3, 1.0,
    &CONTROL_SYSTEM_V2_B.MATLABSystem_o4, 1.0);

  /* Gain: '<Root>/Multiply' */
  rtb_Fcn3 = CONTROL_SYSTEM_V2_P.Multiply_Gain *
    CONTROL_SYSTEM_V2_B.MATLABSystem_o3;

  /* Fcn: '<S5>/Fcn1' incorporates:
   *  Fcn: '<S5>/Fcn3'
   */
  rtb_FromWs = sin(2.0 * rtb_Fcn3);

  /* Gain: '<S4>/Gain1' incorporates:
   *  Fcn: '<S5>/Fcn1'
   *  Fcn: '<S5>/Fcn2'
   *  Fcn: '<S5>/Fcn3'
   */
  CONTROL_SYSTEM_V2_B.Gain1[0] = ((10.0 * rtb_FromWs + 10.0) + 7.0) *
    CONTROL_SYSTEM_V2_P.Gain1_Gain;
  CONTROL_SYSTEM_V2_B.Gain1[1] = cos(2.0 * rtb_Fcn3) * 20.0 *
    CONTROL_SYSTEM_V2_P.Gain1_Gain;
  CONTROL_SYSTEM_V2_B.Gain1[2] = -40.0 * rtb_FromWs *
    CONTROL_SYSTEM_V2_P.Gain1_Gain;

  /* FromWorkspace: '<S21>/FromWs' incorporates:
   *  Sum: '<S11>/Sum3'
   */
  rtb_Fcn3 = CONTROL_SYSTEM_V2_B.Gain1[0] - CONTROL_SYSTEM_V2_B.Integrator1[0];

  /* Product: '<S11>/Product' incorporates:
   *  Gain: '<S11>/Gain'
   *  Gain: '<S11>/Gain1'
   *  Sum: '<S11>/Sum1'
   *  Sum: '<S11>/Sum2'
   *  Sum: '<S11>/Sum4'
   */
  CONTROL_SYSTEM_V2_B.Product = (((2.0 * CONTROL_SYSTEM_V2_P.omga_c *
    (CONTROL_SYSTEM_V2_B.Gain1[1] - CONTROL_SYSTEM_V2_B.Integrator1[1]) +
    CONTROL_SYSTEM_V2_P.Gain_Gain_p * rtb_Fcn3) + CONTROL_SYSTEM_V2_B.Gain1[2])
    - CONTROL_SYSTEM_V2_B.Integrator1[2]) * CONTROL_SYSTEM_V2_B.Fcn;

  /* Product: '<S12>/Product' incorporates:
   *  Constant: '<S12>/Constant2'
   *  Product: '<S1>/Product'
   */
  rtb_FromWs = CONTROL_SYSTEM_V2_P.roa / CONTROL_SYSTEM_V2_P.J_aet *
    CONTROL_SYSTEM_V2_B.Product;

  /* Sum: '<S12>/Sum' incorporates:
   *  Constant: '<S12>/Constant'
   *  Constant: '<S12>/Constant1'
   *  Product: '<S12>/Product'
   */
  CONTROL_SYSTEM_V2_B.Sum[0] = CONTROL_SYSTEM_V2_P.Constant_Value +
    CONTROL_SYSTEM_V2_B.Sum1_j[0];
  CONTROL_SYSTEM_V2_B.Sum[1] = rtb_FromWs + CONTROL_SYSTEM_V2_B.Sum1_j[1];
  CONTROL_SYSTEM_V2_B.Sum[2] = CONTROL_SYSTEM_V2_P.Constant1_Value +
    CONTROL_SYSTEM_V2_B.Sum1_j[2];
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
  }

  /* MATLABSystem: '<S10>/Digital Input' */
  if (CONTROL_SYSTEM_V2_DW.obj_b.SampleTime !=
      CONTROL_SYSTEM_V2_P.DigitalInput_SampleTime) {
    CONTROL_SYSTEM_V2_DW.obj_b.SampleTime =
      CONTROL_SYSTEM_V2_P.DigitalInput_SampleTime;
  }

  LogicalOperator1 = readDigitalPin(36);

  /* MATLABSystem: '<S10>/Digital Input3' */
  if (CONTROL_SYSTEM_V2_DW.obj_g.SampleTime !=
      CONTROL_SYSTEM_V2_P.DigitalInput3_SampleTime) {
    CONTROL_SYSTEM_V2_DW.obj_g.SampleTime =
      CONTROL_SYSTEM_V2_P.DigitalInput3_SampleTime;
  }

  c_value = readDigitalPin(35);

  /* MATLABSystem: '<S10>/Digital Input1' */
  if (CONTROL_SYSTEM_V2_DW.obj_n.SampleTime !=
      CONTROL_SYSTEM_V2_P.DigitalInput1_SampleTime) {
    CONTROL_SYSTEM_V2_DW.obj_n.SampleTime =
      CONTROL_SYSTEM_V2_P.DigitalInput1_SampleTime;
  }

  c_value_0 = readDigitalPin(39);

  /* MATLABSystem: '<S10>/Digital Input2' */
  if (CONTROL_SYSTEM_V2_DW.obj_j.SampleTime !=
      CONTROL_SYSTEM_V2_P.DigitalInput2_SampleTime) {
    CONTROL_SYSTEM_V2_DW.obj_j.SampleTime =
      CONTROL_SYSTEM_V2_P.DigitalInput2_SampleTime;
  }

  c_value_1 = readDigitalPin(34);
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
    /* Memory: '<S42>/Memory' */
    CONTROL_SYSTEM_V2_B.Memory = CONTROL_SYSTEM_V2_DW.Memory_PreviousInput;
  }

  /* Logic: '<S10>/Logical Operator16' incorporates:
   *  Logic: '<S10>/Logical Operator38'
   *  Logic: '<S10>/Logical Operator46'
   *  MATLABSystem: '<S10>/Digital Input3'
   * */
  rowIdx_tmp = !c_value;

  /* Logic: '<S10>/Logical Operator17' incorporates:
   *  Logic: '<S10>/Logical Operator33'
   *  MATLABSystem: '<S10>/Digital Input2'
   * */
  rowIdx_tmp_0 = !c_value_1;

  /* Logic: '<S10>/Logical Operator22' incorporates:
   *  Logic: '<S10>/Logical Operator41'
   *  MATLABSystem: '<S10>/Digital Input1'
   * */
  rowIdx_tmp_2 = !c_value_0;

  /* Logic: '<S10>/Logical Operator21' incorporates:
   *  Logic: '<S10>/Logical Operator17'
   *  Logic: '<S10>/Logical Operator22'
   *  Logic: '<S10>/Logical Operator29'
   */
  rowIdx_tmp_3 = (rowIdx_tmp_2 && rowIdx_tmp_0);

  /* Logic: '<S10>/Logical Operator23' incorporates:
   *  Logic: '<S10>/Logical Operator31'
   *  MATLABSystem: '<S10>/Digital Input1'
   *  MATLABSystem: '<S10>/Digital Input2'
   * */
  rowIdx_tmp_4 = (int8_T)((int8_T)c_value_0 ^ (int8_T)c_value_1);

  /* CombinatorialLogic: '<S42>/Logic' incorporates:
   *  Logic: '<S10>/Logical Operator16'
   *  Logic: '<S10>/Logical Operator18'
   *  Logic: '<S10>/Logical Operator19'
   *  Logic: '<S10>/Logical Operator20'
   *  Logic: '<S10>/Logical Operator21'
   *  Logic: '<S10>/Logical Operator23'
   *  MATLABSystem: '<S10>/Digital Input'
   *  MATLABSystem: '<S10>/Digital Input3'
   * */
  rowIdx = (int32_T)(((((uint32_T)(LogicalOperator1 && (rowIdx_tmp &&
    rowIdx_tmp_3)) << 1) + (uint32_T)(int8_T)(rowIdx_tmp_4 ^ (int8_T)c_value)) <<
                      1) + CONTROL_SYSTEM_V2_B.Memory);
  CONTROL_SYSTEM_V2_B.Logic[0U] = CONTROL_SYSTEM_V2_P.Logic_table[(uint32_T)
    rowIdx];
  CONTROL_SYSTEM_V2_B.Logic[1U] = CONTROL_SYSTEM_V2_P.Logic_table[(uint32_T)
    rowIdx + 8U];

  /* MATLABSystem: '<S3>/Digital Output' */
  writeDigitalPin(27, (uint8_T)CONTROL_SYSTEM_V2_B.Logic[0]);
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
    /* Memory: '<S44>/Memory' */
    CONTROL_SYSTEM_V2_B.Memory_l = CONTROL_SYSTEM_V2_DW.Memory_PreviousInput_c;
  }

  /* Logic: '<S10>/Logical Operator32' incorporates:
   *  Logic: '<S10>/Logical Operator24'
   *  Logic: '<S10>/Logical Operator40'
   *  MATLABSystem: '<S10>/Digital Input'
   * */
  rowIdx_tmp_1 = !LogicalOperator1;

  /* CombinatorialLogic: '<S44>/Logic' incorporates:
   *  Logic: '<S10>/Logical Operator32'
   *  Logic: '<S10>/Logical Operator34'
   *  Logic: '<S10>/Logical Operator35'
   *  Logic: '<S10>/Logical Operator36'
   *  Logic: '<S10>/Logical Operator37'
   *  Logic: '<S10>/Logical Operator39'
   *  MATLABSystem: '<S10>/Digital Input'
   *  MATLABSystem: '<S10>/Digital Input1'
   *  MATLABSystem: '<S10>/Digital Input2'
   *  MATLABSystem: '<S10>/Digital Input3'
   * */
  rowIdx = (int32_T)(((((uint32_T)(c_value_0 && (rowIdx_tmp_1 && (rowIdx_tmp &&
    rowIdx_tmp_0))) << 1) + (uint32_T)(int8_T)((int8_T)((int8_T)c_value ^
    (int8_T)c_value_1) ^ (int8_T)LogicalOperator1)) << 1) +
                     CONTROL_SYSTEM_V2_B.Memory_l);
  CONTROL_SYSTEM_V2_B.Logic_l[0U] = CONTROL_SYSTEM_V2_P.Logic_table_c[(uint32_T)
    rowIdx];
  CONTROL_SYSTEM_V2_B.Logic_l[1U] = CONTROL_SYSTEM_V2_P.Logic_table_c[(uint32_T)
    rowIdx + 8U];

  /* MATLABSystem: '<S3>/Digital Output1' */
  writeDigitalPin(26, (uint8_T)CONTROL_SYSTEM_V2_B.Logic_l[0]);
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
    /* Memory: '<S45>/Memory' */
    CONTROL_SYSTEM_V2_B.Memory_g = CONTROL_SYSTEM_V2_DW.Memory_PreviousInput_b;
  }

  /* CombinatorialLogic: '<S45>/Logic' incorporates:
   *  Logic: '<S10>/Logical Operator42'
   *  Logic: '<S10>/Logical Operator43'
   *  Logic: '<S10>/Logical Operator44'
   *  Logic: '<S10>/Logical Operator45'
   *  Logic: '<S10>/Logical Operator47'
   *  MATLABSystem: '<S10>/Digital Input'
   *  MATLABSystem: '<S10>/Digital Input1'
   *  MATLABSystem: '<S10>/Digital Input2'
   *  MATLABSystem: '<S10>/Digital Input3'
   * */
  rowIdx = (int32_T)(((((uint32_T)(c_value_1 && (rowIdx_tmp_1 && (rowIdx_tmp &&
    rowIdx_tmp_2))) << 1) + (uint32_T)(int8_T)((int8_T)((int8_T)c_value ^
    (int8_T)c_value_0) ^ (int8_T)LogicalOperator1)) << 1) +
                     CONTROL_SYSTEM_V2_B.Memory_g);
  CONTROL_SYSTEM_V2_B.Logic_n[0U] = CONTROL_SYSTEM_V2_P.Logic_table_k[(uint32_T)
    rowIdx];
  CONTROL_SYSTEM_V2_B.Logic_n[1U] = CONTROL_SYSTEM_V2_P.Logic_table_k[(uint32_T)
    rowIdx + 8U];

  /* MATLABSystem: '<S3>/Digital Output2' */
  writeDigitalPin(25, (uint8_T)CONTROL_SYSTEM_V2_B.Logic_n[0]);
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
    /* Memory: '<S43>/Memory' */
    CONTROL_SYSTEM_V2_B.Memory_f = CONTROL_SYSTEM_V2_DW.Memory_PreviousInput_m;
  }

  /* CombinatorialLogic: '<S43>/Logic' incorporates:
   *  Logic: '<S10>/Logical Operator26'
   *  Logic: '<S10>/Logical Operator27'
   *  Logic: '<S10>/Logical Operator28'
   *  MATLABSystem: '<S10>/Digital Input'
   *  MATLABSystem: '<S10>/Digital Input3'
   * */
  rowIdx = (int32_T)(((((uint32_T)(c_value && (rowIdx_tmp_1 && rowIdx_tmp_3)) <<
                        1) + (uint32_T)(int8_T)(rowIdx_tmp_4 ^ (int8_T)
    LogicalOperator1)) << 1) + CONTROL_SYSTEM_V2_B.Memory_f);
  CONTROL_SYSTEM_V2_B.Logic_j[0U] = CONTROL_SYSTEM_V2_P.Logic_table_p[(uint32_T)
    rowIdx];
  CONTROL_SYSTEM_V2_B.Logic_j[1U] = CONTROL_SYSTEM_V2_P.Logic_table_p[(uint32_T)
    rowIdx + 8U];

  /* MATLABSystem: '<S3>/Digital Output3' */
  writeDigitalPin(33, (uint8_T)CONTROL_SYSTEM_V2_B.Logic_j[0]);
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
  }

  /* Clock: '<S23>/Clock' */
  rtb_Clock = CONTROL_SYSTEM_V2_M->Timing.t[0];
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
    /* RelationalOperator: '<S23>/Relational Operator1' incorporates:
     *  Constant: '<S23>/Constant'
     *  Constant: '<S23>/Constant2'
     */
    CONTROL_SYSTEM_V2_B.RelationalOperator1 =
      (CONTROL_SYSTEM_V2_P.OnDelay_DelayType ==
       CONTROL_SYSTEM_V2_P.Constant_Value_l);

    /* Outputs for Enabled SubSystem: '<S23>/ON Delay' incorporates:
     *  EnablePort: '<S25>/Enable'
     */
    if (rtsiIsModeUpdateTimeStep(&CONTROL_SYSTEM_V2_M->solverInfo)) {
      if (CONTROL_SYSTEM_V2_B.RelationalOperator1) {
        CONTROL_SYSTEM_V2_DW.ONDelay_MODE = true;
      } else if (CONTROL_SYSTEM_V2_DW.ONDelay_MODE) {
        /* Disable for Enabled SubSystem: '<S36>/POSITIVE Edge' */
        if (CONTROL_SYSTEM_V2_DW.POSITIVEEdge_h.POSITIVEEdge_MODE) {
          CONTROL_SY_POSITIVEEdge_Disable(&CONTROL_SYSTEM_V2_DW.POSITIVEEdge_h);
        }

        /* End of Disable for SubSystem: '<S36>/POSITIVE Edge' */

        /* Disable for Enabled SubSystem: '<S36>/NEGATIVE Edge' */
        if (CONTROL_SYSTEM_V2_DW.NEGATIVEEdge_e.NEGATIVEEdge_MODE) {
          CONTROL_SY_NEGATIVEEdge_Disable(&CONTROL_SYSTEM_V2_DW.NEGATIVEEdge_e);
        }

        /* End of Disable for SubSystem: '<S36>/NEGATIVE Edge' */
        CONTROL_SYSTEM_V2_DW.ONDelay_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S23>/ON Delay' */
  }

  /* Outputs for Enabled SubSystem: '<S23>/ON Delay' incorporates:
   *  EnablePort: '<S25>/Enable'
   */
  if (CONTROL_SYSTEM_V2_DW.ONDelay_MODE) {
    if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
      /* MultiPortSwitch: '<S36>/Multiport Switch' incorporates:
       *  Constant: '<S36>/Constant1'
       */
      switch ((int32_T)CONTROL_SYSTEM_V2_P.EdgeDetector_model_p) {
       case 1:
        /* MultiPortSwitch: '<S36>/Multiport Switch' incorporates:
         *  Constant: '<S36>/pos. edge'
         */
        CONTROL_SYSTEM_V2_B.MultiportSwitch[0] =
          CONTROL_SYSTEM_V2_P.posedge_Value_d[0];
        CONTROL_SYSTEM_V2_B.MultiportSwitch[1] =
          CONTROL_SYSTEM_V2_P.posedge_Value_d[1];
        break;

       case 2:
        /* MultiPortSwitch: '<S36>/Multiport Switch' incorporates:
         *  Constant: '<S36>/neg. edge'
         */
        CONTROL_SYSTEM_V2_B.MultiportSwitch[0] =
          CONTROL_SYSTEM_V2_P.negedge_Value_c[0];
        CONTROL_SYSTEM_V2_B.MultiportSwitch[1] =
          CONTROL_SYSTEM_V2_P.negedge_Value_c[1];
        break;

       default:
        /* MultiPortSwitch: '<S36>/Multiport Switch' incorporates:
         *  Constant: '<S36>/either edge'
         */
        CONTROL_SYSTEM_V2_B.MultiportSwitch[0] =
          CONTROL_SYSTEM_V2_P.eitheredge_Value_m[0];
        CONTROL_SYSTEM_V2_B.MultiportSwitch[1] =
          CONTROL_SYSTEM_V2_P.eitheredge_Value_m[1];
        break;
      }

      /* End of MultiPortSwitch: '<S36>/Multiport Switch' */

      /* Memory: '<S36>/Memory' */
      CONTROL_SYSTEM_V2_B.Memory_l1 =
        CONTROL_SYSTEM_V2_DW.Memory_PreviousInput_i;
    }

    /* Outputs for Enabled SubSystem: '<S36>/POSITIVE Edge' */
    CONTROL_SYSTEM_V2_POSITIVEEdge(CONTROL_SYSTEM_V2_M,
      CONTROL_SYSTEM_V2_B.MultiportSwitch[0], CONTROL_SYSTEM_V2_B.Logic_j[0],
      CONTROL_SYSTEM_V2_B.Memory_l1, &CONTROL_SYSTEM_V2_B.RelationalOperator1_c,
      &CONTROL_SYSTEM_V2_DW.POSITIVEEdge_h);

    /* End of Outputs for SubSystem: '<S36>/POSITIVE Edge' */

    /* Outputs for Enabled SubSystem: '<S36>/NEGATIVE Edge' */
    CONTROL_SYSTEM_V2_NEGATIVEEdge(CONTROL_SYSTEM_V2_M,
      CONTROL_SYSTEM_V2_B.MultiportSwitch[1], CONTROL_SYSTEM_V2_B.Logic_j[0],
      CONTROL_SYSTEM_V2_B.Memory_l1, &CONTROL_SYSTEM_V2_B.RelationalOperator1_g,
      &CONTROL_SYSTEM_V2_DW.NEGATIVEEdge_e);

    /* End of Outputs for SubSystem: '<S36>/NEGATIVE Edge' */

    /* Logic: '<S36>/Logical Operator1' */
    LogicalOperator1 = (CONTROL_SYSTEM_V2_B.RelationalOperator1_c ||
                        CONTROL_SYSTEM_V2_B.RelationalOperator1_g);
    if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
      /* Memory: '<S41>/IC=ic' */
      CONTROL_SYSTEM_V2_B.ICic = CONTROL_SYSTEM_V2_DW.ICic_PreviousInput;
    }

    /* Switch: '<S41>/Switch' */
    if (LogicalOperator1) {
      /* Switch: '<S41>/Switch' */
      CONTROL_SYSTEM_V2_B.Switch = rtb_Clock;
    } else {
      /* Switch: '<S41>/Switch' */
      CONTROL_SYSTEM_V2_B.Switch = CONTROL_SYSTEM_V2_B.ICic;
    }

    /* End of Switch: '<S41>/Switch' */

    /* Logic: '<S25>/Logical Operator2' incorporates:
     *  Constant: '<S23>/Constant1'
     *  RelationalOperator: '<S25>/Relational Operator'
     *  Sum: '<S25>/Sum'
     */
    CONTROL_SYSTEM_V2_B.LogicalOperator2_d = ((rtb_Clock >=
      CONTROL_SYSTEM_V2_B.Switch + CONTROL_SYSTEM_V2_P.OnDelay_delay) &&
      CONTROL_SYSTEM_V2_B.Logic_j[0]);
    if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
      /* Outputs for Triggered SubSystem: '<S37>/Triggered Subsystem' incorporates:
       *  TriggerPort: '<S40>/Trigger'
       */
      if (rtsiIsModeUpdateTimeStep(&CONTROL_SYSTEM_V2_M->solverInfo)) {
        if (LogicalOperator1 &&
            (CONTROL_SYSTEM_V2_PrevZCX.TriggeredSubsystem_Trig_ZCE != POS_ZCSIG))
        {
          CONTROL_SYSTEM_V2_DW.TriggeredSubsystem_SubsysRanBC = 4;
        }

        CONTROL_SYSTEM_V2_PrevZCX.TriggeredSubsystem_Trig_ZCE = LogicalOperator1;
      }

      /* End of Outputs for SubSystem: '<S37>/Triggered Subsystem' */
    }

    if (rtsiIsModeUpdateTimeStep(&CONTROL_SYSTEM_V2_M->solverInfo)) {
      srUpdateBC(CONTROL_SYSTEM_V2_DW.ONDelay_SubsysRanBC);
    }
  }

  /* End of Outputs for SubSystem: '<S23>/ON Delay' */
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
    /* Outputs for Enabled SubSystem: '<S23>/OFF Delay' incorporates:
     *  EnablePort: '<S24>/Enable'
     */
    if (rtsiIsModeUpdateTimeStep(&CONTROL_SYSTEM_V2_M->solverInfo)) {
      /* Logic: '<S23>/Logical Operator2' */
      if (!CONTROL_SYSTEM_V2_B.RelationalOperator1) {
        CONTROL_SYSTEM_V2_DW.OFFDelay_MODE = true;
      } else if (CONTROL_SYSTEM_V2_DW.OFFDelay_MODE) {
        /* Disable for Enabled SubSystem: '<S28>/POSITIVE Edge' */
        if (CONTROL_SYSTEM_V2_DW.POSITIVEEdge.POSITIVEEdge_MODE) {
          CONTROL_SY_POSITIVEEdge_Disable(&CONTROL_SYSTEM_V2_DW.POSITIVEEdge);
        }

        /* End of Disable for SubSystem: '<S28>/POSITIVE Edge' */

        /* Disable for Enabled SubSystem: '<S28>/NEGATIVE Edge' */
        if (CONTROL_SYSTEM_V2_DW.NEGATIVEEdge.NEGATIVEEdge_MODE) {
          CONTROL_SY_NEGATIVEEdge_Disable(&CONTROL_SYSTEM_V2_DW.NEGATIVEEdge);
        }

        /* End of Disable for SubSystem: '<S28>/NEGATIVE Edge' */
        CONTROL_SYSTEM_V2_DW.OFFDelay_MODE = false;
      }

      /* End of Logic: '<S23>/Logical Operator2' */
    }

    /* End of Outputs for SubSystem: '<S23>/OFF Delay' */
  }

  /* Outputs for Enabled SubSystem: '<S23>/OFF Delay' incorporates:
   *  EnablePort: '<S24>/Enable'
   */
  if (CONTROL_SYSTEM_V2_DW.OFFDelay_MODE) {
    if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
      /* MultiPortSwitch: '<S28>/Multiport Switch' incorporates:
       *  Constant: '<S28>/Constant1'
       */
      switch ((int32_T)CONTROL_SYSTEM_V2_P.EdgeDetector_model) {
       case 1:
        /* MultiPortSwitch: '<S28>/Multiport Switch' incorporates:
         *  Constant: '<S28>/pos. edge'
         */
        CONTROL_SYSTEM_V2_B.MultiportSwitch_c[0] =
          CONTROL_SYSTEM_V2_P.posedge_Value[0];
        CONTROL_SYSTEM_V2_B.MultiportSwitch_c[1] =
          CONTROL_SYSTEM_V2_P.posedge_Value[1];
        break;

       case 2:
        /* MultiPortSwitch: '<S28>/Multiport Switch' incorporates:
         *  Constant: '<S28>/neg. edge'
         */
        CONTROL_SYSTEM_V2_B.MultiportSwitch_c[0] =
          CONTROL_SYSTEM_V2_P.negedge_Value[0];
        CONTROL_SYSTEM_V2_B.MultiportSwitch_c[1] =
          CONTROL_SYSTEM_V2_P.negedge_Value[1];
        break;

       default:
        /* MultiPortSwitch: '<S28>/Multiport Switch' incorporates:
         *  Constant: '<S28>/either edge'
         */
        CONTROL_SYSTEM_V2_B.MultiportSwitch_c[0] =
          CONTROL_SYSTEM_V2_P.eitheredge_Value[0];
        CONTROL_SYSTEM_V2_B.MultiportSwitch_c[1] =
          CONTROL_SYSTEM_V2_P.eitheredge_Value[1];
        break;
      }

      /* End of MultiPortSwitch: '<S28>/Multiport Switch' */

      /* Memory: '<S28>/Memory' */
      CONTROL_SYSTEM_V2_B.Memory_a = CONTROL_SYSTEM_V2_DW.Memory_PreviousInput_l;
    }

    /* Outputs for Enabled SubSystem: '<S28>/POSITIVE Edge' */
    CONTROL_SYSTEM_V2_POSITIVEEdge(CONTROL_SYSTEM_V2_M,
      CONTROL_SYSTEM_V2_B.MultiportSwitch_c[0], CONTROL_SYSTEM_V2_B.Logic_j[0],
      CONTROL_SYSTEM_V2_B.Memory_a, &CONTROL_SYSTEM_V2_B.RelationalOperator1_f,
      &CONTROL_SYSTEM_V2_DW.POSITIVEEdge);

    /* End of Outputs for SubSystem: '<S28>/POSITIVE Edge' */

    /* Outputs for Enabled SubSystem: '<S28>/NEGATIVE Edge' */
    CONTROL_SYSTEM_V2_NEGATIVEEdge(CONTROL_SYSTEM_V2_M,
      CONTROL_SYSTEM_V2_B.MultiportSwitch_c[1], CONTROL_SYSTEM_V2_B.Logic_j[0],
      CONTROL_SYSTEM_V2_B.Memory_a, &CONTROL_SYSTEM_V2_B.RelationalOperator1_m,
      &CONTROL_SYSTEM_V2_DW.NEGATIVEEdge);

    /* End of Outputs for SubSystem: '<S28>/NEGATIVE Edge' */

    /* Logic: '<S28>/Logical Operator1' */
    LogicalOperator1 = (CONTROL_SYSTEM_V2_B.RelationalOperator1_f ||
                        CONTROL_SYSTEM_V2_B.RelationalOperator1_m);
    if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
      /* Memory: '<S33>/IC=ic' */
      CONTROL_SYSTEM_V2_B.ICic_p = CONTROL_SYSTEM_V2_DW.ICic_PreviousInput_k;
    }

    /* Switch: '<S33>/Switch' */
    if (LogicalOperator1) {
      /* Switch: '<S33>/Switch' */
      CONTROL_SYSTEM_V2_B.Switch_n = rtb_Clock;
    } else {
      /* Switch: '<S33>/Switch' */
      CONTROL_SYSTEM_V2_B.Switch_n = CONTROL_SYSTEM_V2_B.ICic_p;
    }

    /* End of Switch: '<S33>/Switch' */

    /* Logic: '<S24>/Logical Operator2' incorporates:
     *  Constant: '<S23>/Constant1'
     *  Logic: '<S24>/Logical Operator'
     *  Logic: '<S24>/Logical Operator1'
     *  RelationalOperator: '<S24>/Relational Operator'
     *  Sum: '<S24>/Sum'
     */
    CONTROL_SYSTEM_V2_B.LogicalOperator2_n = ((!(rtb_Clock >=
      CONTROL_SYSTEM_V2_B.Switch_n + CONTROL_SYSTEM_V2_P.OnDelay_delay)) ||
      CONTROL_SYSTEM_V2_B.Logic_j[0]);
    if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
      /* Outputs for Triggered SubSystem: '<S29>/Triggered Subsystem' incorporates:
       *  TriggerPort: '<S32>/Trigger'
       */
      if (rtsiIsModeUpdateTimeStep(&CONTROL_SYSTEM_V2_M->solverInfo)) {
        if (LogicalOperator1 &&
            (CONTROL_SYSTEM_V2_PrevZCX.TriggeredSubsystem_Trig_ZCE_d !=
             POS_ZCSIG)) {
          CONTROL_SYSTEM_V2_DW.TriggeredSubsystem_SubsysRanB_n = 4;
        }

        CONTROL_SYSTEM_V2_PrevZCX.TriggeredSubsystem_Trig_ZCE_d =
          LogicalOperator1;
      }

      /* End of Outputs for SubSystem: '<S29>/Triggered Subsystem' */
    }

    if (rtsiIsModeUpdateTimeStep(&CONTROL_SYSTEM_V2_M->solverInfo)) {
      srUpdateBC(CONTROL_SYSTEM_V2_DW.OFFDelay_SubsysRanBC);
    }
  }

  /* End of Outputs for SubSystem: '<S23>/OFF Delay' */
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
    /* Sum: '<S7>/Add2' incorporates:
     *  Constant: '<S7>/Desire Max Value'
     *  Constant: '<S7>/Desire Min Value'
     */
    CONTROL_SYSTEM_V2_B.Add2 = CONTROL_SYSTEM_V2_P.Desire_Max -
      CONTROL_SYSTEM_V2_P.Desire_Min;

    /* MATLAB Function: '<Root>/Foot Pedal Calibration1' */
    if (CONTROL_SYSTEM_V2_B.MATLABSystem_o3 > CONTROL_SYSTEM_V2_DW.maxSet) {
      CONTROL_SYSTEM_V2_DW.maxSet = CONTROL_SYSTEM_V2_B.MATLABSystem_o3;
    }

    if (CONTROL_SYSTEM_V2_B.MATLABSystem_o3 < CONTROL_SYSTEM_V2_DW.minSet) {
      CONTROL_SYSTEM_V2_DW.minSet = CONTROL_SYSTEM_V2_B.MATLABSystem_o3;
    }

    CONTROL_SYSTEM_V2_B.FP_maxVal = CONTROL_SYSTEM_V2_DW.maxSet;
    CONTROL_SYSTEM_V2_B.FP_minVal = CONTROL_SYSTEM_V2_DW.minSet;

    /* End of MATLAB Function: '<Root>/Foot Pedal Calibration1' */

    /* Sum: '<S7>/Add3' */
    CONTROL_SYSTEM_V2_B.Add3 = CONTROL_SYSTEM_V2_B.FP_maxVal -
      CONTROL_SYSTEM_V2_B.FP_minVal;

    /* Sum: '<S7>/Sum' incorporates:
     *  Constant: '<S7>/Desire Min Value'
     *  Product: '<S7>/Divide1'
     *  Product: '<S7>/Product1'
     *  Sum: '<S7>/Subtract'
     */
    CONTROL_SYSTEM_V2_B.Sum_h = CONTROL_SYSTEM_V2_B.Add2 /
      CONTROL_SYSTEM_V2_B.Add3 * (0.0 - CONTROL_SYSTEM_V2_B.FP_minVal) +
      CONTROL_SYSTEM_V2_P.Desire_Min;
  }

  /* Switch: '<S9>/Switch2' incorporates:
   *  Constant: '<S9>/Constant'
   *  Logic: '<S23>/Logical Operator1'
   *  Switch: '<S9>/Switch1'
   */
  if (CONTROL_SYSTEM_V2_B.LogicalOperator2_d ||
      CONTROL_SYSTEM_V2_B.LogicalOperator2_n) {
    rtb_Clock = CONTROL_SYSTEM_V2_P.Constant_Value_k;
  } else if (CONTROL_SYSTEM_V2_B.Logic_j[0]) {
    /* Switch: '<S9>/Switch1' incorporates:
     *  Gain: '<S9>/Gain'
     */
    rtb_Clock = (real_T)(CONTROL_SYSTEM_V2_B.Logic_j[0] ? (int32_T)
                         CONTROL_SYSTEM_V2_P.Gain_Gain_j : 0) * 0.5;
  } else {
    /* Switch: '<S9>/Switch1' */
    rtb_Clock = CONTROL_SYSTEM_V2_B.Sum_h;
  }

  /* End of Switch: '<S9>/Switch2' */

  /* Start for MATLABSystem: '<S9>/PWM' */
  if (!(rtb_Clock <= 255.0)) {
    rtb_Clock = 255.0;
  }

  /* MATLABSystem: '<S9>/PWM' */
  CONTROL_SYSTEM_V2_DW.obj_jn.PWMDriverObj.MW_PWM_HANDLE = MW_PWM_GetHandle(4U);

  /* Start for MATLABSystem: '<S9>/PWM' */
  if (!(rtb_Clock >= 0.0)) {
    rtb_Clock = 0.0;
  }

  /* MATLABSystem: '<S9>/PWM' */
  MW_PWM_SetDutyCycle(CONTROL_SYSTEM_V2_DW.obj_jn.PWMDriverObj.MW_PWM_HANDLE,
                      -(rtb_Clock * 255.0 / 255.0));
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
    /* Sum: '<S13>/Add2' */
    CONTROL_SYSTEM_V2_B.Add2_h = CONTROL_SYSTEM_V2_B.FP_maxVal -
      CONTROL_SYSTEM_V2_B.FP_minVal;

    /* MATLAB Function: '<Root>/Throttle Body Callibration1' */
    if (CONTROL_SYSTEM_V2_B.MATLABSystem_o2 > CONTROL_SYSTEM_V2_DW.TB_maxSet) {
      CONTROL_SYSTEM_V2_DW.TB_maxSet = CONTROL_SYSTEM_V2_B.MATLABSystem_o2;
    }

    if (CONTROL_SYSTEM_V2_B.MATLABSystem_o2 < CONTROL_SYSTEM_V2_DW.TB_minSet) {
      CONTROL_SYSTEM_V2_DW.TB_minSet = CONTROL_SYSTEM_V2_B.MATLABSystem_o2;
    }

    CONTROL_SYSTEM_V2_B.TB_maxVal = CONTROL_SYSTEM_V2_DW.TB_maxSet;
    CONTROL_SYSTEM_V2_B.TB_minVal = CONTROL_SYSTEM_V2_DW.TB_minSet;

    /* End of MATLAB Function: '<Root>/Throttle Body Callibration1' */

    /* Sum: '<S13>/Add3' */
    CONTROL_SYSTEM_V2_B.Add3_n = CONTROL_SYSTEM_V2_B.TB_maxVal -
      CONTROL_SYSTEM_V2_B.TB_minVal;

    /* Product: '<S13>/Divide1' */
    CONTROL_SYSTEM_V2_B.Divide1 = CONTROL_SYSTEM_V2_B.Add2_h /
      CONTROL_SYSTEM_V2_B.Add3_n;
  }

  /* Sum: '<S13>/Sum' incorporates:
   *  Product: '<S13>/Product1'
   *  Sum: '<S13>/Subtract'
   */
  CONTROL_SYSTEM_V2_B.Sum_o = (CONTROL_SYSTEM_V2_B.MATLABSystem_o2 -
    CONTROL_SYSTEM_V2_B.TB_minVal) * CONTROL_SYSTEM_V2_B.Divide1 +
    CONTROL_SYSTEM_V2_B.FP_minVal;
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
    /* Gain: '<S15>/Gain1' incorporates:
     *  Constant: '<S1>/Constant1'
     */
    CONTROL_SYSTEM_V2_B.Gain1_i = CONTROL_SYSTEM_V2_P.Gain1_Gain_h *
      CONTROL_SYSTEM_V2_P.theta_o;
  }

  /* Sum: '<S1>/Sum2' incorporates:
   *  Integrator: '<S1>/Integrator'
   */
  rtb_Sum2_m = CONTROL_SYSTEM_V2_X.Integrator_CSTATE -
    CONTROL_SYSTEM_V2_B.Gain1_i;

  /* Integrator: '<S1>/Integrator1' */
  CONTROL_SYSTEM_V2_B.Integrator1_a = CONTROL_SYSTEM_V2_X.Integrator1_CSTATE_k;

  /* Signum: '<S1>/Sign' */
  if (rtIsNaN(CONTROL_SYSTEM_V2_B.Integrator1_a)) {
    rtb_Clock = (rtNaN);
  } else if (CONTROL_SYSTEM_V2_B.Integrator1_a < 0.0) {
    rtb_Clock = -1.0;
  } else {
    rtb_Clock = (CONTROL_SYSTEM_V2_B.Integrator1_a > 0.0);
  }

  /* Signum: '<S1>/Sign1' */
  if (rtIsNaN(rtb_Sum2_m)) {
    tmp = (rtNaN);
  } else if (rtb_Sum2_m < 0.0) {
    tmp = -1.0;
  } else {
    tmp = (rtb_Sum2_m > 0.0);
  }

  /* Sum: '<S1>/Sum' incorporates:
   *  Constant: '<S1>/Constant'
   *  Gain: '<S1>/Gain1'
   *  Gain: '<S1>/Gain2'
   *  Gain: '<S1>/Gain3'
   *  Gain: '<S1>/Gain4'
   *  Product: '<S1>/Product1'
   *  Signum: '<S1>/Sign'
   *  Signum: '<S1>/Sign1'
   *  Sum: '<S1>/Sum1'
   */
  CONTROL_SYSTEM_V2_B.Sum_d = (((-CONTROL_SYSTEM_V2_P.B_aet *
    CONTROL_SYSTEM_V2_B.Integrator1_a + -CONTROL_SYSTEM_V2_P.K_sp * rtb_Sum2_m)
    + -CONTROL_SYSTEM_V2_P.F_so * rtb_Clock) + -CONTROL_SYSTEM_V2_P.Toa_ho * tmp)
    * (1.0 / CONTROL_SYSTEM_V2_P.J_aet) + rtb_FromWs;

  /* Gain: '<S46>/Gain' */
  CONTROL_SYSTEM_V2_B.Gain = CONTROL_SYSTEM_V2_P.Gain_Gain_h * rtb_Fcn3;
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
    /* Constant: '<S9>/Enable Pin' */
    CONTROL_SYSTEM_V2_B.EnablePin = CONTROL_SYSTEM_V2_P.EN_Pin;

    /* MATLABSystem: '<S9>/Digital Output' */
    rtb_Clock = rt_roundd_snf(CONTROL_SYSTEM_V2_B.EnablePin);
    if (rtb_Clock < 256.0) {
      if (rtb_Clock >= 0.0) {
        tmp_0 = (uint8_T)rtb_Clock;
      } else {
        tmp_0 = 0U;
      }
    } else {
      tmp_0 = MAX_uint8_T;
    }

    writeDigitalPin(0, tmp_0);

    /* End of MATLABSystem: '<S9>/Digital Output' */
    /* Constant: '<S9>/Direction Pin' */
    CONTROL_SYSTEM_V2_B.DirectionPin = CONTROL_SYSTEM_V2_P.Direction_Pin;

    /* MATLABSystem: '<S9>/Digital Output1' */
    rtb_Clock = rt_roundd_snf(CONTROL_SYSTEM_V2_B.DirectionPin);
    if (rtb_Clock < 256.0) {
      if (rtb_Clock >= 0.0) {
        tmp_0 = (uint8_T)rtb_Clock;
      } else {
        tmp_0 = 0U;
      }
    } else {
      tmp_0 = MAX_uint8_T;
    }

    writeDigitalPin(16, tmp_0);

    /* End of MATLABSystem: '<S9>/Digital Output1' */
  }

  /* FromWorkspace: '<S17>/FromWs' */
  {
    real_T *pDataValues = (real_T *) CONTROL_SYSTEM_V2_DW.FromWs_PWORK.DataPtr;
    real_T *pTimeValues = (real_T *) CONTROL_SYSTEM_V2_DW.FromWs_PWORK.TimePtr;
    int_T currTimeIndex = CONTROL_SYSTEM_V2_DW.FromWs_IWORK.PrevIndex;
    real_T t = CONTROL_SYSTEM_V2_M->Timing.t[0];

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[5]) {
      currTimeIndex = 4;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    CONTROL_SYSTEM_V2_DW.FromWs_IWORK.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          rtb_Fcn3 = pDataValues[currTimeIndex];
        } else {
          rtb_Fcn3 = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex = currTimeIndex;
        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        rtb_Fcn3 = (real_T) rtInterpolate(d1, d2, f1, f2);
        pDataValues += 6;
      }
    }
  }

  /* FromWorkspace: '<S18>/FromWs' */
  {
    real_T *pDataValues = (real_T *) CONTROL_SYSTEM_V2_DW.FromWs_PWORK_e.DataPtr;
    real_T *pTimeValues = (real_T *) CONTROL_SYSTEM_V2_DW.FromWs_PWORK_e.TimePtr;
    int_T currTimeIndex = CONTROL_SYSTEM_V2_DW.FromWs_IWORK_p.PrevIndex;
    real_T t = CONTROL_SYSTEM_V2_M->Timing.t[0];

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[5]) {
      currTimeIndex = 4;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    CONTROL_SYSTEM_V2_DW.FromWs_IWORK_p.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          rtb_FromWs = pDataValues[currTimeIndex];
        } else {
          rtb_FromWs = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex = currTimeIndex;
        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        rtb_FromWs = (real_T) rtInterpolate(d1, d2, f1, f2);
        pDataValues += 6;
      }
    }
  }

  /* Sum: '<S6>/Sum2' */
  rtb_FromWs += rtb_Fcn3;

  /* FromWorkspace: '<S19>/FromWs' */
  {
    real_T *pDataValues = (real_T *) CONTROL_SYSTEM_V2_DW.FromWs_PWORK_g.DataPtr;
    real_T *pTimeValues = (real_T *) CONTROL_SYSTEM_V2_DW.FromWs_PWORK_g.TimePtr;
    int_T currTimeIndex = CONTROL_SYSTEM_V2_DW.FromWs_IWORK_i.PrevIndex;
    real_T t = CONTROL_SYSTEM_V2_M->Timing.t[0];

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[5]) {
      currTimeIndex = 4;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    CONTROL_SYSTEM_V2_DW.FromWs_IWORK_i.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          rtb_Fcn3 = pDataValues[currTimeIndex];
        } else {
          rtb_Fcn3 = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex = currTimeIndex;
        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        rtb_Fcn3 = (real_T) rtInterpolate(d1, d2, f1, f2);
        pDataValues += 6;
      }
    }
  }

  /* Gain: '<S6>/Gain' */
  rtb_Clock = CONTROL_SYSTEM_V2_P.Gain_Gain_i * rtb_Fcn3;

  /* FromWorkspace: '<S20>/FromWs' */
  {
    real_T *pDataValues = (real_T *) CONTROL_SYSTEM_V2_DW.FromWs_PWORK_n.DataPtr;
    real_T *pTimeValues = (real_T *) CONTROL_SYSTEM_V2_DW.FromWs_PWORK_n.TimePtr;
    int_T currTimeIndex = CONTROL_SYSTEM_V2_DW.FromWs_IWORK_o.PrevIndex;
    real_T t = CONTROL_SYSTEM_V2_M->Timing.t[0];

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[5]) {
      currTimeIndex = 4;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    CONTROL_SYSTEM_V2_DW.FromWs_IWORK_o.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          rtb_Fcn3 = pDataValues[currTimeIndex];
        } else {
          rtb_Fcn3 = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex = currTimeIndex;
        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        rtb_Fcn3 = (real_T) rtInterpolate(d1, d2, f1, f2);
        pDataValues += 6;
      }
    }
  }

  /* Sum: '<S6>/Sum3' incorporates:
   *  Gain: '<S6>/Gain1'
   *  Sum: '<S6>/Sum4'
   */
  rtb_FromWs = (rtb_FromWs + rtb_Clock) + CONTROL_SYSTEM_V2_P.Gain1_Gain_c *
    rtb_Fcn3;

  /* FromWorkspace: '<S21>/FromWs' */
  {
    real_T *pDataValues = (real_T *) CONTROL_SYSTEM_V2_DW.FromWs_PWORK_b.DataPtr;
    real_T *pTimeValues = (real_T *) CONTROL_SYSTEM_V2_DW.FromWs_PWORK_b.TimePtr;
    int_T currTimeIndex = CONTROL_SYSTEM_V2_DW.FromWs_IWORK_f.PrevIndex;
    real_T t = CONTROL_SYSTEM_V2_M->Timing.t[0];

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[3]) {
      currTimeIndex = 2;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    CONTROL_SYSTEM_V2_DW.FromWs_IWORK_f.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          rtb_Fcn3 = pDataValues[currTimeIndex];
        } else {
          rtb_Fcn3 = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex = currTimeIndex;
        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        rtb_Fcn3 = (real_T) rtInterpolate(d1, d2, f1, f2);
        pDataValues += 4;
      }
    }
  }

  /* Gain: '<S16>/Gain' incorporates:
   *  Gain: '<S6>/Gain2'
   *  Sum: '<S6>/Sum5'
   */
  CONTROL_SYSTEM_V2_B.Gain_g = (rtb_FromWs - CONTROL_SYSTEM_V2_P.Gain2_Gain_f *
    rtb_Fcn3) * CONTROL_SYSTEM_V2_P.Gain_Gain_c;
  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
  }

  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
    if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
      /* Update for Memory: '<S42>/Memory' */
      CONTROL_SYSTEM_V2_DW.Memory_PreviousInput = CONTROL_SYSTEM_V2_B.Logic[0];

      /* Update for Memory: '<S44>/Memory' */
      CONTROL_SYSTEM_V2_DW.Memory_PreviousInput_c = CONTROL_SYSTEM_V2_B.Logic_l
        [0];

      /* Update for Memory: '<S45>/Memory' */
      CONTROL_SYSTEM_V2_DW.Memory_PreviousInput_b = CONTROL_SYSTEM_V2_B.Logic_n
        [0];

      /* Update for Memory: '<S43>/Memory' */
      CONTROL_SYSTEM_V2_DW.Memory_PreviousInput_m = CONTROL_SYSTEM_V2_B.Logic_j
        [0];
    }

    /* Update for Enabled SubSystem: '<S23>/ON Delay' incorporates:
     *  EnablePort: '<S25>/Enable'
     */
    if (CONTROL_SYSTEM_V2_DW.ONDelay_MODE && rtmIsMajorTimeStep
        (CONTROL_SYSTEM_V2_M)) {
      /* Update for Memory: '<S36>/Memory' */
      CONTROL_SYSTEM_V2_DW.Memory_PreviousInput_i = CONTROL_SYSTEM_V2_B.Logic_j
        [0];

      /* Update for Memory: '<S41>/IC=ic' */
      CONTROL_SYSTEM_V2_DW.ICic_PreviousInput = CONTROL_SYSTEM_V2_B.Switch;
    }

    /* End of Update for SubSystem: '<S23>/ON Delay' */

    /* Update for Enabled SubSystem: '<S23>/OFF Delay' incorporates:
     *  EnablePort: '<S24>/Enable'
     */
    if (CONTROL_SYSTEM_V2_DW.OFFDelay_MODE && rtmIsMajorTimeStep
        (CONTROL_SYSTEM_V2_M)) {
      /* Update for Memory: '<S28>/Memory' */
      CONTROL_SYSTEM_V2_DW.Memory_PreviousInput_l = CONTROL_SYSTEM_V2_B.Logic_j
        [0];

      /* Update for Memory: '<S33>/IC=ic' */
      CONTROL_SYSTEM_V2_DW.ICic_PreviousInput_k = CONTROL_SYSTEM_V2_B.Switch_n;
    }

    /* End of Update for SubSystem: '<S23>/OFF Delay' */
    if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {/* Sample time: [0.2s, 0.0s] */
      extmodeErrorCode_T errorCode = EXTMODE_SUCCESS;
      extmodeSimulationTime_T currentTime = (extmodeSimulationTime_T)
        ((CONTROL_SYSTEM_V2_M->Timing.clockTick1) * 0.2);

      /* Trigger External Mode event */
      errorCode = extmodeEvent(1,currentTime);
      if (errorCode != EXTMODE_SUCCESS) {
        /* Code to handle External Mode event errors
           may be added here */
      }
    }
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(CONTROL_SYSTEM_V2_M)) {
    rt_ertODEUpdateContinuousStates(&CONTROL_SYSTEM_V2_M->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     */
    ++CONTROL_SYSTEM_V2_M->Timing.clockTick0;
    CONTROL_SYSTEM_V2_M->Timing.t[0] = rtsiGetSolverStopTime
      (&CONTROL_SYSTEM_V2_M->solverInfo);

    {
      /* Update absolute timer for sample time: [0.2s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.2, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       */
      CONTROL_SYSTEM_V2_M->Timing.clockTick1++;
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void CONTROL_SYSTEM_V2_derivatives(void)
{
  XDot_CONTROL_SYSTEM_V2_T *_rtXdot;
  _rtXdot = ((XDot_CONTROL_SYSTEM_V2_T *) CONTROL_SYSTEM_V2_M->derivs);

  /* Derivatives for Integrator: '<S12>/Integrator1' */
  _rtXdot->Integrator1_CSTATE[0] = CONTROL_SYSTEM_V2_B.Sum[0];
  _rtXdot->Integrator1_CSTATE[1] = CONTROL_SYSTEM_V2_B.Sum[1];
  _rtXdot->Integrator1_CSTATE[2] = CONTROL_SYSTEM_V2_B.Sum[2];

  /* Derivatives for Integrator: '<S1>/Integrator' */
  _rtXdot->Integrator_CSTATE = CONTROL_SYSTEM_V2_B.Integrator1_a;

  /* Derivatives for Integrator: '<S1>/Integrator1' */
  _rtXdot->Integrator1_CSTATE_k = CONTROL_SYSTEM_V2_B.Sum_d;
}

/* Model initialize function */
void CONTROL_SYSTEM_V2_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&CONTROL_SYSTEM_V2_M->solverInfo,
                          &CONTROL_SYSTEM_V2_M->Timing.simTimeStep);
    rtsiSetTPtr(&CONTROL_SYSTEM_V2_M->solverInfo, &rtmGetTPtr
                (CONTROL_SYSTEM_V2_M));
    rtsiSetStepSizePtr(&CONTROL_SYSTEM_V2_M->solverInfo,
                       &CONTROL_SYSTEM_V2_M->Timing.stepSize0);
    rtsiSetdXPtr(&CONTROL_SYSTEM_V2_M->solverInfo, &CONTROL_SYSTEM_V2_M->derivs);
    rtsiSetContStatesPtr(&CONTROL_SYSTEM_V2_M->solverInfo, (real_T **)
                         &CONTROL_SYSTEM_V2_M->contStates);
    rtsiSetNumContStatesPtr(&CONTROL_SYSTEM_V2_M->solverInfo,
      &CONTROL_SYSTEM_V2_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&CONTROL_SYSTEM_V2_M->solverInfo,
      &CONTROL_SYSTEM_V2_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&CONTROL_SYSTEM_V2_M->solverInfo,
      &CONTROL_SYSTEM_V2_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&CONTROL_SYSTEM_V2_M->solverInfo,
      &CONTROL_SYSTEM_V2_M->periodicContStateRanges);
    rtsiSetContStateDisabledPtr(&CONTROL_SYSTEM_V2_M->solverInfo, (boolean_T**)
      &CONTROL_SYSTEM_V2_M->contStateDisabled);
    rtsiSetErrorStatusPtr(&CONTROL_SYSTEM_V2_M->solverInfo, (&rtmGetErrorStatus
      (CONTROL_SYSTEM_V2_M)));
    rtsiSetRTModelPtr(&CONTROL_SYSTEM_V2_M->solverInfo, CONTROL_SYSTEM_V2_M);
  }

  rtsiSetSimTimeStep(&CONTROL_SYSTEM_V2_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetIsMinorTimeStepWithModeChange(&CONTROL_SYSTEM_V2_M->solverInfo, false);
  rtsiSetIsContModeFrozen(&CONTROL_SYSTEM_V2_M->solverInfo, false);
  CONTROL_SYSTEM_V2_M->intgData.y = CONTROL_SYSTEM_V2_M->odeY;
  CONTROL_SYSTEM_V2_M->intgData.f[0] = CONTROL_SYSTEM_V2_M->odeF[0];
  CONTROL_SYSTEM_V2_M->intgData.f[1] = CONTROL_SYSTEM_V2_M->odeF[1];
  CONTROL_SYSTEM_V2_M->intgData.f[2] = CONTROL_SYSTEM_V2_M->odeF[2];
  CONTROL_SYSTEM_V2_M->contStates = ((X_CONTROL_SYSTEM_V2_T *)
    &CONTROL_SYSTEM_V2_X);
  CONTROL_SYSTEM_V2_M->contStateDisabled = ((XDis_CONTROL_SYSTEM_V2_T *)
    &CONTROL_SYSTEM_V2_XDis);
  CONTROL_SYSTEM_V2_M->Timing.tStart = (0.0);
  rtsiSetSolverData(&CONTROL_SYSTEM_V2_M->solverInfo, (void *)
                    &CONTROL_SYSTEM_V2_M->intgData);
  rtsiSetSolverName(&CONTROL_SYSTEM_V2_M->solverInfo,"ode3");
  rtmSetTPtr(CONTROL_SYSTEM_V2_M, &CONTROL_SYSTEM_V2_M->Timing.tArray[0]);
  rtmSetTFinal(CONTROL_SYSTEM_V2_M, -1);
  CONTROL_SYSTEM_V2_M->Timing.stepSize0 = 0.2;

  /* External mode info */
  CONTROL_SYSTEM_V2_M->Sizes.checksums[0] = (3395777090U);
  CONTROL_SYSTEM_V2_M->Sizes.checksums[1] = (3308678889U);
  CONTROL_SYSTEM_V2_M->Sizes.checksums[2] = (2899597121U);
  CONTROL_SYSTEM_V2_M->Sizes.checksums[3] = (439425872U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[31];
    CONTROL_SYSTEM_V2_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    systemRan[8] = &rtAlwaysEnabled;
    systemRan[9] = (sysRanDType *)
      &CONTROL_SYSTEM_V2_DW.TriggeredSubsystem_SubsysRanB_n;
    systemRan[10] = (sysRanDType *)
      &CONTROL_SYSTEM_V2_DW.NEGATIVEEdge.NEGATIVEEdge_SubsysRanBC;
    systemRan[11] = (sysRanDType *)
      &CONTROL_SYSTEM_V2_DW.POSITIVEEdge.POSITIVEEdge_SubsysRanBC;
    systemRan[12] = (sysRanDType *)&CONTROL_SYSTEM_V2_DW.OFFDelay_SubsysRanBC;
    systemRan[13] = (sysRanDType *)&CONTROL_SYSTEM_V2_DW.OFFDelay_SubsysRanBC;
    systemRan[14] = (sysRanDType *)&CONTROL_SYSTEM_V2_DW.OFFDelay_SubsysRanBC;
    systemRan[15] = (sysRanDType *)&CONTROL_SYSTEM_V2_DW.OFFDelay_SubsysRanBC;
    systemRan[16] = (sysRanDType *)
      &CONTROL_SYSTEM_V2_DW.TriggeredSubsystem_SubsysRanBC;
    systemRan[17] = (sysRanDType *)
      &CONTROL_SYSTEM_V2_DW.NEGATIVEEdge_e.NEGATIVEEdge_SubsysRanBC;
    systemRan[18] = (sysRanDType *)
      &CONTROL_SYSTEM_V2_DW.POSITIVEEdge_h.POSITIVEEdge_SubsysRanBC;
    systemRan[19] = (sysRanDType *)&CONTROL_SYSTEM_V2_DW.ONDelay_SubsysRanBC;
    systemRan[20] = (sysRanDType *)&CONTROL_SYSTEM_V2_DW.ONDelay_SubsysRanBC;
    systemRan[21] = (sysRanDType *)&CONTROL_SYSTEM_V2_DW.ONDelay_SubsysRanBC;
    systemRan[22] = (sysRanDType *)&CONTROL_SYSTEM_V2_DW.ONDelay_SubsysRanBC;
    systemRan[23] = &rtAlwaysEnabled;
    systemRan[24] = &rtAlwaysEnabled;
    systemRan[25] = &rtAlwaysEnabled;
    systemRan[26] = &rtAlwaysEnabled;
    systemRan[27] = &rtAlwaysEnabled;
    systemRan[28] = &rtAlwaysEnabled;
    systemRan[29] = &rtAlwaysEnabled;
    systemRan[30] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(CONTROL_SYSTEM_V2_M->extModeInfo,
      &CONTROL_SYSTEM_V2_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(CONTROL_SYSTEM_V2_M->extModeInfo,
                        CONTROL_SYSTEM_V2_M->Sizes.checksums);
    rteiSetTPtr(CONTROL_SYSTEM_V2_M->extModeInfo, rtmGetTPtr(CONTROL_SYSTEM_V2_M));
  }

  /* Start for FromWorkspace: '<S17>/FromWs' */
  {
    static real_T pTimeValues0[] = { 0.0, 1.0, 1.0, 5.0, 5.0, 8.0 } ;

    static real_T pDataValues0[] = { 0.0, 0.0, 1.5, 1.5, 0.0, 0.0 } ;

    CONTROL_SYSTEM_V2_DW.FromWs_PWORK.TimePtr = (void *) pTimeValues0;
    CONTROL_SYSTEM_V2_DW.FromWs_PWORK.DataPtr = (void *) pDataValues0;
    CONTROL_SYSTEM_V2_DW.FromWs_IWORK.PrevIndex = 0;
  }

  /* Start for FromWorkspace: '<S18>/FromWs' */
  {
    static real_T pTimeValues0[] = { 0.0, 9.0, 9.0, 13.0, 13.0, 14.0 } ;

    static real_T pDataValues0[] = { 0.0, 0.0, 1.5, 1.5, 1.0, 1.0 } ;

    CONTROL_SYSTEM_V2_DW.FromWs_PWORK_e.TimePtr = (void *) pTimeValues0;
    CONTROL_SYSTEM_V2_DW.FromWs_PWORK_e.DataPtr = (void *) pDataValues0;
    CONTROL_SYSTEM_V2_DW.FromWs_IWORK_p.PrevIndex = 0;
  }

  /* Start for FromWorkspace: '<S19>/FromWs' */
  {
    static real_T pTimeValues0[] = { 0.0, 16.95, 16.95, 20.0, 20.0, 21.0 } ;

    static real_T pDataValues0[] = { 0.0, 0.0, 0.5, 0.5, -0.0, -0.0 } ;

    CONTROL_SYSTEM_V2_DW.FromWs_PWORK_g.TimePtr = (void *) pTimeValues0;
    CONTROL_SYSTEM_V2_DW.FromWs_PWORK_g.DataPtr = (void *) pDataValues0;
    CONTROL_SYSTEM_V2_DW.FromWs_IWORK_i.PrevIndex = 0;
  }

  /* Start for FromWorkspace: '<S20>/FromWs' */
  {
    static real_T pTimeValues0[] = { 0.0, 20.0, 20.0, 21.0, 21.0, 25.0 } ;

    static real_T pDataValues0[] = { 0.0, 0.0, 0.5, 0.5, -0.0, -0.0 } ;

    CONTROL_SYSTEM_V2_DW.FromWs_PWORK_n.TimePtr = (void *) pTimeValues0;
    CONTROL_SYSTEM_V2_DW.FromWs_PWORK_n.DataPtr = (void *) pDataValues0;
    CONTROL_SYSTEM_V2_DW.FromWs_IWORK_o.PrevIndex = 0;
  }

  /* Start for FromWorkspace: '<S21>/FromWs' */
  {
    static real_T pTimeValues0[] = { 0.0, 21.0, 21.0, 25.0 } ;

    static real_T pDataValues0[] = { 0.0, 0.0, 1.0, 1.0 } ;

    CONTROL_SYSTEM_V2_DW.FromWs_PWORK_b.TimePtr = (void *) pTimeValues0;
    CONTROL_SYSTEM_V2_DW.FromWs_PWORK_b.DataPtr = (void *) pDataValues0;
    CONTROL_SYSTEM_V2_DW.FromWs_IWORK_f.PrevIndex = 0;
  }

  CONTROL_SYSTEM_V2_PrevZCX.TriggeredSubsystem_Trig_ZCE_d = POS_ZCSIG;
  CONTROL_SYSTEM_V2_PrevZCX.TriggeredSubsystem_Trig_ZCE = POS_ZCSIG;

  /* InitializeConditions for Integrator: '<S12>/Integrator1' */
  CONTROL_SYSTEM_V2_X.Integrator1_CSTATE[0] =
    CONTROL_SYSTEM_V2_P.Integrator1_IC[0];
  CONTROL_SYSTEM_V2_X.Integrator1_CSTATE[1] =
    CONTROL_SYSTEM_V2_P.Integrator1_IC[1];
  CONTROL_SYSTEM_V2_X.Integrator1_CSTATE[2] =
    CONTROL_SYSTEM_V2_P.Integrator1_IC[2];

  /* InitializeConditions for Integrator: '<S1>/Integrator' */
  CONTROL_SYSTEM_V2_X.Integrator_CSTATE = CONTROL_SYSTEM_V2_P.Integrator_IC;

  /* InitializeConditions for Memory: '<S42>/Memory' */
  CONTROL_SYSTEM_V2_DW.Memory_PreviousInput =
    CONTROL_SYSTEM_V2_P.SRFlipFlop3_initial_condition;

  /* InitializeConditions for Memory: '<S44>/Memory' */
  CONTROL_SYSTEM_V2_DW.Memory_PreviousInput_c =
    CONTROL_SYSTEM_V2_P.SRFlipFlop5_initial_condition;

  /* InitializeConditions for Memory: '<S45>/Memory' */
  CONTROL_SYSTEM_V2_DW.Memory_PreviousInput_b =
    CONTROL_SYSTEM_V2_P.SRFlipFlop6_initial_condition;

  /* InitializeConditions for Memory: '<S43>/Memory' */
  CONTROL_SYSTEM_V2_DW.Memory_PreviousInput_m =
    CONTROL_SYSTEM_V2_P.SRFlipFlop4_initial_condition;

  /* InitializeConditions for Integrator: '<S1>/Integrator1' */
  CONTROL_SYSTEM_V2_X.Integrator1_CSTATE_k =
    CONTROL_SYSTEM_V2_P.Integrator1_IC_o;

  /* SystemInitialize for Enabled SubSystem: '<S23>/ON Delay' */
  /* InitializeConditions for Memory: '<S36>/Memory' */
  CONTROL_SYSTEM_V2_DW.Memory_PreviousInput_i = CONTROL_SYSTEM_V2_P.OnDelay_ic;

  /* InitializeConditions for Memory: '<S41>/IC=ic' */
  CONTROL_SYSTEM_V2_DW.ICic_PreviousInput =
    CONTROL_SYSTEM_V2_P.SampleandHold_ic_n;

  /* SystemInitialize for Enabled SubSystem: '<S36>/POSITIVE Edge' */
  CONTROL_SYSTE_POSITIVEEdge_Init(&CONTROL_SYSTEM_V2_B.RelationalOperator1_c,
    &CONTROL_SYSTEM_V2_P.POSITIVEEdge_h);

  /* End of SystemInitialize for SubSystem: '<S36>/POSITIVE Edge' */

  /* SystemInitialize for Enabled SubSystem: '<S36>/NEGATIVE Edge' */
  CONTROL_SYSTE_NEGATIVEEdge_Init(&CONTROL_SYSTEM_V2_B.RelationalOperator1_g,
    &CONTROL_SYSTEM_V2_P.NEGATIVEEdge_e);

  /* End of SystemInitialize for SubSystem: '<S36>/NEGATIVE Edge' */

  /* SystemInitialize for Logic: '<S25>/Logical Operator2' incorporates:
   *  Outport: '<S25>/OUT'
   */
  CONTROL_SYSTEM_V2_B.LogicalOperator2_d = CONTROL_SYSTEM_V2_P.OUT_Y0_a;

  /* End of SystemInitialize for SubSystem: '<S23>/ON Delay' */

  /* SystemInitialize for Enabled SubSystem: '<S23>/OFF Delay' */
  /* InitializeConditions for Memory: '<S28>/Memory' */
  CONTROL_SYSTEM_V2_DW.Memory_PreviousInput_l = CONTROL_SYSTEM_V2_P.OnDelay_ic;

  /* InitializeConditions for Memory: '<S33>/IC=ic' */
  CONTROL_SYSTEM_V2_DW.ICic_PreviousInput_k =
    CONTROL_SYSTEM_V2_P.SampleandHold_ic;

  /* SystemInitialize for Enabled SubSystem: '<S28>/POSITIVE Edge' */
  CONTROL_SYSTE_POSITIVEEdge_Init(&CONTROL_SYSTEM_V2_B.RelationalOperator1_f,
    &CONTROL_SYSTEM_V2_P.POSITIVEEdge);

  /* End of SystemInitialize for SubSystem: '<S28>/POSITIVE Edge' */

  /* SystemInitialize for Enabled SubSystem: '<S28>/NEGATIVE Edge' */
  CONTROL_SYSTE_NEGATIVEEdge_Init(&CONTROL_SYSTEM_V2_B.RelationalOperator1_m,
    &CONTROL_SYSTEM_V2_P.NEGATIVEEdge);

  /* End of SystemInitialize for SubSystem: '<S28>/NEGATIVE Edge' */

  /* SystemInitialize for Logic: '<S24>/Logical Operator2' incorporates:
   *  Outport: '<S24>/OUT'
   */
  CONTROL_SYSTEM_V2_B.LogicalOperator2_n = CONTROL_SYSTEM_V2_P.OUT_Y0;

  /* End of SystemInitialize for SubSystem: '<S23>/OFF Delay' */

  /* SystemInitialize for MATLAB Function: '<Root>/Foot Pedal Calibration1' */
  CONTROL_SYSTEM_V2_DW.maxSet = -1.0;
  CONTROL_SYSTEM_V2_DW.minSet = 5.0;

  /* SystemInitialize for MATLAB Function: '<Root>/Throttle Body Callibration1' */
  CONTROL_SYSTEM_V2_DW.TB_maxSet = -1.0;
  CONTROL_SYSTEM_V2_DW.TB_minSet = 5.0;

  /* Start for MATLABSystem: '<S2>/MATLAB System' */
  /*  Constructor */
  CONTROL_SYSTEM_V2_DW.obj.matlabCodegenIsDeleted = false;
  CONTROL_SYSTEM_V2_DW.obj.SampleTime =
    CONTROL_SYSTEM_V2_P.MATLABSystem_SampleTime;
  CONTROL_SYSTEM_V2_DW.obj.isInitialized = 1;

  /*         %% Define output properties */
  /*   Check the input size */
  setupFunctionADS1115_Vread(16, 1.0);
  CONTROL_SYSTEM_V2_DW.obj.isSetupComplete = true;

  /* Start for MATLABSystem: '<S10>/Digital Input' */
  CONTROL_SYSTEM_V2_DW.obj_b.matlabCodegenIsDeleted = false;
  CONTROL_SYSTEM_V2_DW.obj_b.SampleTime =
    CONTROL_SYSTEM_V2_P.DigitalInput_SampleTime;
  CONTROL_SYSTEM_V2_DW.obj_b.isInitialized = 1;
  digitalIOSetup(36, 0);
  CONTROL_SYSTEM_V2_DW.obj_b.isSetupComplete = true;

  /* Start for MATLABSystem: '<S10>/Digital Input3' */
  CONTROL_SYSTEM_V2_DW.obj_g.matlabCodegenIsDeleted = false;
  CONTROL_SYSTEM_V2_DW.obj_g.SampleTime =
    CONTROL_SYSTEM_V2_P.DigitalInput3_SampleTime;
  CONTROL_SYSTEM_V2_DW.obj_g.isInitialized = 1;
  digitalIOSetup(35, 0);
  CONTROL_SYSTEM_V2_DW.obj_g.isSetupComplete = true;

  /* Start for MATLABSystem: '<S10>/Digital Input1' */
  CONTROL_SYSTEM_V2_DW.obj_n.matlabCodegenIsDeleted = false;
  CONTROL_SYSTEM_V2_DW.obj_n.SampleTime =
    CONTROL_SYSTEM_V2_P.DigitalInput1_SampleTime;
  CONTROL_SYSTEM_V2_DW.obj_n.isInitialized = 1;
  digitalIOSetup(39, 0);
  CONTROL_SYSTEM_V2_DW.obj_n.isSetupComplete = true;

  /* Start for MATLABSystem: '<S10>/Digital Input2' */
  CONTROL_SYSTEM_V2_DW.obj_j.matlabCodegenIsDeleted = false;
  CONTROL_SYSTEM_V2_DW.obj_j.SampleTime =
    CONTROL_SYSTEM_V2_P.DigitalInput2_SampleTime;
  CONTROL_SYSTEM_V2_DW.obj_j.isInitialized = 1;
  digitalIOSetup(34, 0);
  CONTROL_SYSTEM_V2_DW.obj_j.isSetupComplete = true;

  /* Start for MATLABSystem: '<S3>/Digital Output' */
  CONTROL_SYSTEM_V2_DW.obj_d.matlabCodegenIsDeleted = false;
  CONTROL_SYSTEM_V2_DW.obj_d.isInitialized = 1;
  digitalIOSetup(27, 1);
  CONTROL_SYSTEM_V2_DW.obj_d.isSetupComplete = true;

  /* Start for MATLABSystem: '<S3>/Digital Output1' */
  CONTROL_SYSTEM_V2_DW.obj_ha.matlabCodegenIsDeleted = false;
  CONTROL_SYSTEM_V2_DW.obj_ha.isInitialized = 1;
  digitalIOSetup(26, 1);
  CONTROL_SYSTEM_V2_DW.obj_ha.isSetupComplete = true;

  /* Start for MATLABSystem: '<S3>/Digital Output2' */
  CONTROL_SYSTEM_V2_DW.obj_o.matlabCodegenIsDeleted = false;
  CONTROL_SYSTEM_V2_DW.obj_o.isInitialized = 1;
  digitalIOSetup(25, 1);
  CONTROL_SYSTEM_V2_DW.obj_o.isSetupComplete = true;

  /* Start for MATLABSystem: '<S3>/Digital Output3' */
  CONTROL_SYSTEM_V2_DW.obj_py.matlabCodegenIsDeleted = false;
  CONTROL_SYSTEM_V2_DW.obj_py.isInitialized = 1;
  digitalIOSetup(33, 1);
  CONTROL_SYSTEM_V2_DW.obj_py.isSetupComplete = true;

  /* Start for MATLABSystem: '<S9>/PWM' */
  CONTROL_SYSTEM_V2_DW.obj_jn.matlabCodegenIsDeleted = false;
  CONTROL_SYSTEM_V2_DW.obj_jn.isInitialized = 1;
  CONTROL_SYSTEM_V2_DW.obj_jn.PWMDriverObj.MW_PWM_HANDLE = MW_PWM_Open(4U,
    19000.0, 255.0);
  CONTROL_SYSTEM_V2_DW.obj_jn.isSetupComplete = true;

  /* Start for MATLABSystem: '<S9>/Digital Output' */
  CONTROL_SYSTEM_V2_DW.obj_h.matlabCodegenIsDeleted = false;
  CONTROL_SYSTEM_V2_DW.obj_h.isInitialized = 1;
  digitalIOSetup(0, 1);
  CONTROL_SYSTEM_V2_DW.obj_h.isSetupComplete = true;

  /* Start for MATLABSystem: '<S9>/Digital Output1' */
  CONTROL_SYSTEM_V2_DW.obj_p.matlabCodegenIsDeleted = false;
  CONTROL_SYSTEM_V2_DW.obj_p.isInitialized = 1;
  digitalIOSetup(16, 1);
  CONTROL_SYSTEM_V2_DW.obj_p.isSetupComplete = true;
}

/* Model terminate function */
void CONTROL_SYSTEM_V2_terminate(void)
{
  /* Terminate for MATLABSystem: '<S2>/MATLAB System' */
  if (!CONTROL_SYSTEM_V2_DW.obj.matlabCodegenIsDeleted) {
    CONTROL_SYSTEM_V2_DW.obj.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S2>/MATLAB System' */
  /* Terminate for MATLABSystem: '<S10>/Digital Input' */
  if (!CONTROL_SYSTEM_V2_DW.obj_b.matlabCodegenIsDeleted) {
    CONTROL_SYSTEM_V2_DW.obj_b.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S10>/Digital Input' */

  /* Terminate for MATLABSystem: '<S10>/Digital Input3' */
  if (!CONTROL_SYSTEM_V2_DW.obj_g.matlabCodegenIsDeleted) {
    CONTROL_SYSTEM_V2_DW.obj_g.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S10>/Digital Input3' */

  /* Terminate for MATLABSystem: '<S10>/Digital Input1' */
  if (!CONTROL_SYSTEM_V2_DW.obj_n.matlabCodegenIsDeleted) {
    CONTROL_SYSTEM_V2_DW.obj_n.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S10>/Digital Input1' */

  /* Terminate for MATLABSystem: '<S10>/Digital Input2' */
  if (!CONTROL_SYSTEM_V2_DW.obj_j.matlabCodegenIsDeleted) {
    CONTROL_SYSTEM_V2_DW.obj_j.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S10>/Digital Input2' */

  /* Terminate for MATLABSystem: '<S3>/Digital Output' */
  if (!CONTROL_SYSTEM_V2_DW.obj_d.matlabCodegenIsDeleted) {
    CONTROL_SYSTEM_V2_DW.obj_d.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S3>/Digital Output' */
  /* Terminate for MATLABSystem: '<S3>/Digital Output1' */
  if (!CONTROL_SYSTEM_V2_DW.obj_ha.matlabCodegenIsDeleted) {
    CONTROL_SYSTEM_V2_DW.obj_ha.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S3>/Digital Output1' */
  /* Terminate for MATLABSystem: '<S3>/Digital Output2' */
  if (!CONTROL_SYSTEM_V2_DW.obj_o.matlabCodegenIsDeleted) {
    CONTROL_SYSTEM_V2_DW.obj_o.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S3>/Digital Output2' */
  /* Terminate for MATLABSystem: '<S3>/Digital Output3' */
  if (!CONTROL_SYSTEM_V2_DW.obj_py.matlabCodegenIsDeleted) {
    CONTROL_SYSTEM_V2_DW.obj_py.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S3>/Digital Output3' */
  /* Terminate for MATLABSystem: '<S9>/PWM' */
  if (!CONTROL_SYSTEM_V2_DW.obj_jn.matlabCodegenIsDeleted) {
    CONTROL_SYSTEM_V2_DW.obj_jn.matlabCodegenIsDeleted = true;
    CONTROL_SYST_SystemCore_release(&CONTROL_SYSTEM_V2_DW.obj_jn);
  }

  /* End of Terminate for MATLABSystem: '<S9>/PWM' */
  /* Terminate for MATLABSystem: '<S9>/Digital Output' */
  if (!CONTROL_SYSTEM_V2_DW.obj_h.matlabCodegenIsDeleted) {
    CONTROL_SYSTEM_V2_DW.obj_h.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S9>/Digital Output' */
  /* Terminate for MATLABSystem: '<S9>/Digital Output1' */
  if (!CONTROL_SYSTEM_V2_DW.obj_p.matlabCodegenIsDeleted) {
    CONTROL_SYSTEM_V2_DW.obj_p.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S9>/Digital Output1' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
