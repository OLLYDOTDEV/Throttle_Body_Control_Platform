/*
 * Community and Technical College License -- for use in teaching and
 * meeting course requirements at community and technical colleges only.
 * Not for government, commercial, university, or other organizational
 * use.
 *
 * File: CONTROL_SYSTEM_V2_data.c
 *
 * Code generated for Simulink model 'CONTROL_SYSTEM_V2'.
 *
 * Model version                  : 1.11
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Fri Sep  6 13:49:24 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "CONTROL_SYSTEM_V2.h"

/* Block parameters (default storage) */
P_CONTROL_SYSTEM_V2_T CONTROL_SYSTEM_V2_P = {
  /* Variable: B_aet
   * Referenced by: '<S1>/Constant'
   */
  0.1503,

  /* Variable: Desire_Max
   * Referenced by: '<S7>/Desire Max Value'
   */
  255.0,

  /* Variable: Desire_Min
   * Referenced by: '<S7>/Desire Min Value'
   */
  0.0,

  /* Variable: Direction_Pin
   * Referenced by: '<S9>/Direction Pin'
   */
  1.0,

  /* Variable: EN_Pin
   * Referenced by: '<S9>/Enable Pin'
   */
  0.0,

  /* Variable: F_so
   * Referenced by: '<S1>/Gain2'
   */
  0.089,

  /* Variable: J_aet
   * Referenced by:
   *   '<S1>/Constant2'
   *   '<S1>/Gain4'
   *   '<S11>/Constant2'
   *   '<S12>/Constant2'
   */
  0.0035,

  /* Variable: K_sp
   * Referenced by: '<S1>/Gain1'
   */
  0.0914,

  /* Variable: Toa_ho
   * Referenced by: '<S1>/Gain3'
   */
  0.3193,

  /* Variable: omga_c
   * Referenced by: '<S11>/Gain1'
   */
  100.0,

  /* Variable: roa
   * Referenced by:
   *   '<S1>/Constant2'
   *   '<S11>/Constant2'
   *   '<S12>/Constant2'
   */
  0.24,

  /* Variable: theta_o
   * Referenced by: '<S1>/Constant1'
   */
  12.0,

  /* Mask Parameter: OnDelay_DelayType
   * Referenced by: '<S23>/Constant2'
   */
  1.0,

  /* Mask Parameter: OnDelay_delay
   * Referenced by: '<S23>/Constant1'
   */
  2.0,

  /* Mask Parameter: SampleandHold_ic
   * Referenced by: '<S33>/IC=ic'
   */
  -1.0E+99,

  /* Mask Parameter: SampleandHold_ic_n
   * Referenced by: '<S41>/IC=ic'
   */
  -1.0E+99,

  /* Mask Parameter: EdgeDetector_model
   * Referenced by: '<S28>/Constant1'
   */
  2.0,

  /* Mask Parameter: EdgeDetector_model_p
   * Referenced by: '<S36>/Constant1'
   */
  1.0,

  /* Mask Parameter: OnDelay_ic
   * Referenced by:
   *   '<S28>/Memory'
   *   '<S36>/Memory'
   */
  false,

  /* Mask Parameter: SRFlipFlop3_initial_condition
   * Referenced by: '<S42>/Memory'
   */
  false,

  /* Mask Parameter: SRFlipFlop5_initial_condition
   * Referenced by: '<S44>/Memory'
   */
  false,

  /* Mask Parameter: SRFlipFlop6_initial_condition
   * Referenced by: '<S45>/Memory'
   */
  false,

  /* Mask Parameter: SRFlipFlop4_initial_condition
   * Referenced by: '<S43>/Memory'
   */
  false,

  /* Expression: -1
   * Referenced by: '<S2>/MATLAB System'
   */
  -1.0,

  /* Expression: -1e6
   * Referenced by: '<S32>/Out1'
   */
  -1.0E+6,

  /* Expression: [1 0]
   * Referenced by: '<S28>/pos. edge'
   */
  { 1.0, 0.0 },

  /* Expression: [0 1]
   * Referenced by: '<S28>/neg. edge'
   */
  { 0.0, 1.0 },

  /* Expression: [1 1]
   * Referenced by: '<S28>/either edge'
   */
  { 1.0, 1.0 },

  /* Expression: -1e6
   * Referenced by: '<S40>/Out1'
   */
  -1.0E+6,

  /* Expression: [1 0]
   * Referenced by: '<S36>/pos. edge'
   */
  { 1.0, 0.0 },

  /* Expression: [0 1]
   * Referenced by: '<S36>/neg. edge'
   */
  { 0.0, 1.0 },

  /* Expression: [1 1]
   * Referenced by: '<S36>/either edge'
   */
  { 1.0, 1.0 },

  /* Expression: -1
   * Referenced by: '<S10>/Digital Input'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<S10>/Digital Input1'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<S10>/Digital Input2'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<S10>/Digital Input3'
   */
  -1.0,

  /* Expression: [12*pi/180 0 0]'
   * Referenced by: '<S12>/Integrator1'
   */
  { 0.20943951023931953, 0.0, 0.0 },

  /* Expression: [0 1 0;0 0 1;0 0 0]
   * Referenced by: '<S12>/Gain'
   */
  { 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0 },

  /* Expression: 12*pi/180
   * Referenced by: '<S1>/Integrator'
   */
  0.20943951023931953,

  /* Expression: [Beta1 Beta2 Beta3]'
   * Referenced by: '<S12>/Gain2'
   */
  { 750.0, 187500.0, 1.5625E+7 },

  /* Expression: 0
   * Referenced by: '<S12>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S12>/Constant1'
   */
  0.0,

  /* Expression: 10
   * Referenced by: '<Root>/Multiply'
   */
  10.0,

  /* Expression: pi/180
   * Referenced by: '<S4>/Gain1'
   */
  0.017453292519943295,

  /* Expression: (omga_c)^2
   * Referenced by: '<S11>/Gain'
   */
  10000.0,

  /* Expression: 1
   * Referenced by: '<S23>/Constant'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S9>/Constant'
   */
  0.0,

  /* Expression: pi/180
   * Referenced by: '<S15>/Gain1'
   */
  0.017453292519943295,

  /* Expression: 0
   * Referenced by: '<S1>/Integrator1'
   */
  0.0,

  /* Expression: 180/pi
   * Referenced by: '<S46>/Gain'
   */
  57.295779513082323,

  /* Expression: -1
   * Referenced by: '<S6>/Gain'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<S6>/Gain1'
   */
  -1.0,

  /* Expression: 1
   * Referenced by: '<S6>/Gain2'
   */
  1.0,

  /* Expression: 180/pi
   * Referenced by: '<S16>/Gain'
   */
  57.295779513082323,

  /* Computed Parameter: OUT_Y0
   * Referenced by: '<S24>/OUT'
   */
  false,

  /* Computed Parameter: OUT_Y0_a
   * Referenced by: '<S25>/OUT'
   */
  false,

  /* Computed Parameter: Logic_table
   * Referenced by: '<S42>/Logic'
   */
  { false, true, false, false, true, true, false, false, true, false, true, true,
    false, false, false, false },

  /* Computed Parameter: Logic_table_c
   * Referenced by: '<S44>/Logic'
   */
  { false, true, false, false, true, true, false, false, true, false, true, true,
    false, false, false, false },

  /* Computed Parameter: Logic_table_k
   * Referenced by: '<S45>/Logic'
   */
  { false, true, false, false, true, true, false, false, true, false, true, true,
    false, false, false, false },

  /* Computed Parameter: Logic_table_p
   * Referenced by: '<S43>/Logic'
   */
  { false, true, false, false, true, true, false, false, true, false, true, true,
    false, false, false, false },

  /* Computed Parameter: Gain_Gain_j
   * Referenced by: '<S9>/Gain'
   */
  200U,

  /* Start of '<S36>/POSITIVE Edge' */
  {
    /* Computed Parameter: OUT_Y0
     * Referenced by: '<S39>/OUT'
     */
    false
  }
  ,

  /* End of '<S36>/POSITIVE Edge' */

  /* Start of '<S36>/NEGATIVE Edge' */
  {
    /* Computed Parameter: OUT_Y0
     * Referenced by: '<S38>/OUT'
     */
    false
  }
  ,

  /* End of '<S36>/NEGATIVE Edge' */

  /* Start of '<S28>/POSITIVE Edge' */
  {
    /* Computed Parameter: OUT_Y0
     * Referenced by: '<S31>/OUT'
     */
    false
  }
  ,

  /* End of '<S28>/POSITIVE Edge' */

  /* Start of '<S28>/NEGATIVE Edge' */
  {
    /* Computed Parameter: OUT_Y0
     * Referenced by: '<S30>/OUT'
     */
    false
  }
  /* End of '<S28>/NEGATIVE Edge' */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
