/*
 * Community and Technical College License -- for use in teaching and
 * meeting course requirements at community and technical colleges only.
 * Not for government, commercial, university, or other organizational
 * use.
 *
 * File: CONTROL_SYSTEM_V2.h
 *
 * Code generated for Simulink model 'CONTROL_SYSTEM_V2'.
 *
 * Model version                  : 1.11
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Fri Sep  6 13:49:24 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef CONTROL_SYSTEM_V2_h_
#define CONTROL_SYSTEM_V2_h_
#ifndef CONTROL_SYSTEM_V2_COMMON_INCLUDES_
#define CONTROL_SYSTEM_V2_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "ext_mode.h"
#include "ADS1115_Vread.h"
#include "MW_arduino_digitalio.h"
#include "MW_PWM.h"
#endif                                 /* CONTROL_SYSTEM_V2_COMMON_INCLUDES_ */

#include "CONTROL_SYSTEM_V2_types.h"
#include <math.h>
#include "rt_nonfinite.h"
#include "rtGetNaN.h"
#include <string.h>
#include <stddef.h>
#include "zero_crossing_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetContStateDisabled
#define rtmGetContStateDisabled(rtm)   ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
#define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
#define rtmGetContStates(rtm)          ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
#define rtmSetContStates(rtm, val)     ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
#define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
#define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetIntgData
#define rtmGetIntgData(rtm)            ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
#define rtmSetIntgData(rtm, val)       ((rtm)->intgData = (val))
#endif

#ifndef rtmGetOdeF
#define rtmGetOdeF(rtm)                ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
#define rtmSetOdeF(rtm, val)           ((rtm)->odeF = (val))
#endif

#ifndef rtmGetOdeY
#define rtmGetOdeY(rtm)                ((rtm)->odeY)
#endif

#ifndef rtmSetOdeY
#define rtmSetOdeY(rtm, val)           ((rtm)->odeY = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
#define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
#define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
#define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
#define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetRTWExtModeInfo
#define rtmGetRTWExtModeInfo(rtm)      ((rtm)->extModeInfo)
#endif

#ifndef rtmGetZCCacheNeedsReset
#define rtmGetZCCacheNeedsReset(rtm)   ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
#define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetdX
#define rtmGetdX(rtm)                  ((rtm)->derivs)
#endif

#ifndef rtmSetdX
#define rtmSetdX(rtm, val)             ((rtm)->derivs = (val))
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

#ifndef rtmGetTStart
#define rtmGetTStart(rtm)              ((rtm)->Timing.tStart)
#endif

/* Block states (default storage) for system '<S28>/NEGATIVE Edge' */
typedef struct {
  int8_T NEGATIVEEdge_SubsysRanBC;     /* '<S28>/NEGATIVE Edge' */
  boolean_T NEGATIVEEdge_MODE;         /* '<S28>/NEGATIVE Edge' */
} DW_NEGATIVEEdge_CONTROL_SYSTE_T;

/* Block states (default storage) for system '<S28>/POSITIVE Edge' */
typedef struct {
  int8_T POSITIVEEdge_SubsysRanBC;     /* '<S28>/POSITIVE Edge' */
  boolean_T POSITIVEEdge_MODE;         /* '<S28>/POSITIVE Edge' */
} DW_POSITIVEEdge_CONTROL_SYSTE_T;

/* Block signals (default storage) */
typedef struct {
  real_T Integrator1[3];               /* '<S12>/Integrator1' */
  real_T Gain1[3];                     /* '<S4>/Gain1' */
  real_T Sum1_j[3];                    /* '<S12>/Sum1' */
  real_T Fcn;                          /* '<S11>/Fcn' */
  real_T Product;                      /* '<S11>/Product' */
  real_T Sum[3];                       /* '<S12>/Sum' */
  real_T Add2;                         /* '<S7>/Add2' */
  real_T Add3;                         /* '<S7>/Add3' */
  real_T Sum_h;                        /* '<S7>/Sum' */
  real_T Add2_h;                       /* '<S13>/Add2' */
  real_T Add3_n;                       /* '<S13>/Add3' */
  real_T Divide1;                      /* '<S13>/Divide1' */
  real_T Sum_o;                        /* '<S13>/Sum' */
  real_T Gain1_i;                      /* '<S15>/Gain1' */
  real_T Integrator1_a;                /* '<S1>/Integrator1' */
  real_T Sum_d;                        /* '<S1>/Sum' */
  real_T Gain;                         /* '<S46>/Gain' */
  real_T EnablePin;                    /* '<S9>/Enable Pin' */
  real_T DirectionPin;                 /* '<S9>/Direction Pin' */
  real_T Gain_g;                       /* '<S16>/Gain' */
  real_T TB_maxVal;                   /* '<Root>/Throttle Body Callibration1' */
  real_T TB_minVal;                   /* '<Root>/Throttle Body Callibration1' */
  real_T MultiportSwitch[2];           /* '<S36>/Multiport Switch' */
  real_T ICic;                         /* '<S41>/IC=ic' */
  real_T Switch;                       /* '<S41>/Switch' */
  real_T MultiportSwitch_c[2];         /* '<S28>/Multiport Switch' */
  real_T ICic_p;                       /* '<S33>/IC=ic' */
  real_T Switch_n;                     /* '<S33>/Switch' */
  real_T FP_maxVal;                    /* '<Root>/Foot Pedal Calibration1' */
  real_T FP_minVal;                    /* '<Root>/Foot Pedal Calibration1' */
  real_T MATLABSystem_o1;              /* '<S2>/MATLAB System' */
  real_T MATLABSystem_o2;              /* '<S2>/MATLAB System' */
  real_T MATLABSystem_o3;              /* '<S2>/MATLAB System' */
  real_T MATLABSystem_o4;              /* '<S2>/MATLAB System' */
  boolean_T Memory;                    /* '<S42>/Memory' */
  boolean_T Logic[2];                  /* '<S42>/Logic' */
  boolean_T Memory_l;                  /* '<S44>/Memory' */
  boolean_T Logic_l[2];                /* '<S44>/Logic' */
  boolean_T Memory_g;                  /* '<S45>/Memory' */
  boolean_T Logic_n[2];                /* '<S45>/Logic' */
  boolean_T Memory_f;                  /* '<S43>/Memory' */
  boolean_T Logic_j[2];                /* '<S43>/Logic' */
  boolean_T RelationalOperator1;       /* '<S23>/Relational Operator1' */
  boolean_T Memory_l1;                 /* '<S36>/Memory' */
  boolean_T LogicalOperator2_d;        /* '<S25>/Logical Operator2' */
  boolean_T RelationalOperator1_c;     /* '<S39>/Relational Operator1' */
  boolean_T RelationalOperator1_g;     /* '<S38>/Relational Operator1' */
  boolean_T Memory_a;                  /* '<S28>/Memory' */
  boolean_T LogicalOperator2_n;        /* '<S24>/Logical Operator2' */
  boolean_T RelationalOperator1_f;     /* '<S31>/Relational Operator1' */
  boolean_T RelationalOperator1_m;     /* '<S30>/Relational Operator1' */
} B_CONTROL_SYSTEM_V2_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  ADS1115_Vread_CONTROL_SYSTEM__T obj; /* '<S2>/MATLAB System' */
  codertarget_arduinobase_blo_i_T obj_g;/* '<S10>/Digital Input3' */
  codertarget_arduinobase_blo_i_T obj_j;/* '<S10>/Digital Input2' */
  codertarget_arduinobase_blo_i_T obj_n;/* '<S10>/Digital Input1' */
  codertarget_arduinobase_blo_i_T obj_b;/* '<S10>/Digital Input' */
  codertarget_arduinobase_block_T obj_p;/* '<S9>/Digital Output1' */
  codertarget_arduinobase_block_T obj_h;/* '<S9>/Digital Output' */
  codertarget_arduinobase_block_T obj_py;/* '<S3>/Digital Output3' */
  codertarget_arduinobase_block_T obj_o;/* '<S3>/Digital Output2' */
  codertarget_arduinobase_block_T obj_ha;/* '<S3>/Digital Output1' */
  codertarget_arduinobase_block_T obj_d;/* '<S3>/Digital Output' */
  codertarget_arduinobase_inter_T obj_jn;/* '<S9>/PWM' */
  real_T TB_maxSet;                   /* '<Root>/Throttle Body Callibration1' */
  real_T TB_minSet;                   /* '<Root>/Throttle Body Callibration1' */
  real_T ICic_PreviousInput;           /* '<S41>/IC=ic' */
  real_T ICic_PreviousInput_k;         /* '<S33>/IC=ic' */
  real_T maxSet;                       /* '<Root>/Foot Pedal Calibration1' */
  real_T minSet;                       /* '<Root>/Foot Pedal Calibration1' */
  struct {
    void *LoggedData;
  } Scope_PWORK;                       /* '<S12>/Scope' */

  struct {
    void *LoggedData;
  } Scope1_PWORK;                      /* '<S12>/Scope1' */

  struct {
    void *LoggedData;
  } Contro_inputVoltages1_PWORK;       /* '<Root>/Contro_input (Voltages)1' */

  struct {
    void *LoggedData;
  } Trackingerro1_PWORK;               /* '<Root>/Tracking erro1' */

  struct {
    void *LoggedData;
  } Trackingerro2_PWORK;               /* '<Root>/Tracking erro2' */

  struct {
    void *LoggedData;
  } Trackingerro3_PWORK;               /* '<Root>/Tracking erro3' */

  struct {
    void *LoggedData;
  } Trackingerro1_PWORK_n;             /* '<S11>/Tracking erro1' */

  struct {
    void *LoggedData;
  } Trackingerro2_PWORK_k;             /* '<S11>/Tracking erro2' */

  struct {
    void *LoggedData;
  } Trackingerro3_PWORK_p;             /* '<S11>/Tracking erro3' */

  struct {
    void *LoggedData;
  } Contro_inputVoltages_PWORK;        /* '<Root>/Contro_input (Voltages)' */

  struct {
    void *LoggedData;
  } Trackingerro_PWORK;                /* '<S11>/Tracking erro' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWs_PWORK;                      /* '<S17>/FromWs' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWs_PWORK_e;                    /* '<S18>/FromWs' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWs_PWORK_g;                    /* '<S19>/FromWs' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWs_PWORK_n;                    /* '<S20>/FromWs' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWs_PWORK_b;                    /* '<S21>/FromWs' */

  struct {
    void *LoggedData;
  } Scope_PWORK_d;                     /* '<S6>/Scope' */

  struct {
    int_T PrevIndex;
  } FromWs_IWORK;                      /* '<S17>/FromWs' */

  struct {
    int_T PrevIndex;
  } FromWs_IWORK_p;                    /* '<S18>/FromWs' */

  struct {
    int_T PrevIndex;
  } FromWs_IWORK_i;                    /* '<S19>/FromWs' */

  struct {
    int_T PrevIndex;
  } FromWs_IWORK_o;                    /* '<S20>/FromWs' */

  struct {
    int_T PrevIndex;
  } FromWs_IWORK_f;                    /* '<S21>/FromWs' */

  int8_T ONDelay_SubsysRanBC;          /* '<S23>/ON Delay' */
  int8_T TriggeredSubsystem_SubsysRanBC;/* '<S37>/Triggered Subsystem' */
  int8_T OFFDelay_SubsysRanBC;         /* '<S23>/OFF Delay' */
  int8_T TriggeredSubsystem_SubsysRanB_n;/* '<S29>/Triggered Subsystem' */
  boolean_T Memory_PreviousInput;      /* '<S42>/Memory' */
  boolean_T Memory_PreviousInput_c;    /* '<S44>/Memory' */
  boolean_T Memory_PreviousInput_b;    /* '<S45>/Memory' */
  boolean_T Memory_PreviousInput_m;    /* '<S43>/Memory' */
  boolean_T Memory_PreviousInput_i;    /* '<S36>/Memory' */
  boolean_T Memory_PreviousInput_l;    /* '<S28>/Memory' */
  boolean_T ONDelay_MODE;              /* '<S23>/ON Delay' */
  boolean_T OFFDelay_MODE;             /* '<S23>/OFF Delay' */
  DW_POSITIVEEdge_CONTROL_SYSTE_T POSITIVEEdge_h;/* '<S36>/POSITIVE Edge' */
  DW_NEGATIVEEdge_CONTROL_SYSTE_T NEGATIVEEdge_e;/* '<S36>/NEGATIVE Edge' */
  DW_POSITIVEEdge_CONTROL_SYSTE_T POSITIVEEdge;/* '<S28>/POSITIVE Edge' */
  DW_NEGATIVEEdge_CONTROL_SYSTE_T NEGATIVEEdge;/* '<S28>/NEGATIVE Edge' */
} DW_CONTROL_SYSTEM_V2_T;

/* Continuous states (default storage) */
typedef struct {
  real_T Integrator1_CSTATE[3];        /* '<S12>/Integrator1' */
  real_T Integrator_CSTATE;            /* '<S1>/Integrator' */
  real_T Integrator1_CSTATE_k;         /* '<S1>/Integrator1' */
} X_CONTROL_SYSTEM_V2_T;

/* State derivatives (default storage) */
typedef struct {
  real_T Integrator1_CSTATE[3];        /* '<S12>/Integrator1' */
  real_T Integrator_CSTATE;            /* '<S1>/Integrator' */
  real_T Integrator1_CSTATE_k;         /* '<S1>/Integrator1' */
} XDot_CONTROL_SYSTEM_V2_T;

/* State disabled  */
typedef struct {
  boolean_T Integrator1_CSTATE[3];     /* '<S12>/Integrator1' */
  boolean_T Integrator_CSTATE;         /* '<S1>/Integrator' */
  boolean_T Integrator1_CSTATE_k;      /* '<S1>/Integrator1' */
} XDis_CONTROL_SYSTEM_V2_T;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState TriggeredSubsystem_Trig_ZCE;/* '<S37>/Triggered Subsystem' */
  ZCSigState TriggeredSubsystem_Trig_ZCE_d;/* '<S29>/Triggered Subsystem' */
} PrevZCX_CONTROL_SYSTEM_V2_T;

#ifndef ODE3_INTG
#define ODE3_INTG

/* ODE3 Integration Data */
typedef struct {
  real_T *y;                           /* output */
  real_T *f[3];                        /* derivatives */
} ODE3_IntgData;

#endif

/* Parameters for system: '<S28>/NEGATIVE Edge' */
struct P_NEGATIVEEdge_CONTROL_SYSTEM_T_ {
  boolean_T OUT_Y0;                    /* Computed Parameter: OUT_Y0
                                        * Referenced by: '<S30>/OUT'
                                        */
};

/* Parameters for system: '<S28>/POSITIVE Edge' */
struct P_POSITIVEEdge_CONTROL_SYSTEM_T_ {
  boolean_T OUT_Y0;                    /* Computed Parameter: OUT_Y0
                                        * Referenced by: '<S31>/OUT'
                                        */
};

/* Parameters (default storage) */
struct P_CONTROL_SYSTEM_V2_T_ {
  real_T B_aet;                        /* Variable: B_aet
                                        * Referenced by: '<S1>/Constant'
                                        */
  real_T Desire_Max;                   /* Variable: Desire_Max
                                        * Referenced by: '<S7>/Desire Max Value'
                                        */
  real_T Desire_Min;                   /* Variable: Desire_Min
                                        * Referenced by: '<S7>/Desire Min Value'
                                        */
  real_T Direction_Pin;                /* Variable: Direction_Pin
                                        * Referenced by: '<S9>/Direction Pin'
                                        */
  real_T EN_Pin;                       /* Variable: EN_Pin
                                        * Referenced by: '<S9>/Enable Pin'
                                        */
  real_T F_so;                         /* Variable: F_so
                                        * Referenced by: '<S1>/Gain2'
                                        */
  real_T J_aet;                        /* Variable: J_aet
                                        * Referenced by:
                                        *   '<S1>/Constant2'
                                        *   '<S1>/Gain4'
                                        *   '<S11>/Constant2'
                                        *   '<S12>/Constant2'
                                        */
  real_T K_sp;                         /* Variable: K_sp
                                        * Referenced by: '<S1>/Gain1'
                                        */
  real_T Toa_ho;                       /* Variable: Toa_ho
                                        * Referenced by: '<S1>/Gain3'
                                        */
  real_T omga_c;                       /* Variable: omga_c
                                        * Referenced by: '<S11>/Gain1'
                                        */
  real_T roa;                          /* Variable: roa
                                        * Referenced by:
                                        *   '<S1>/Constant2'
                                        *   '<S11>/Constant2'
                                        *   '<S12>/Constant2'
                                        */
  real_T theta_o;                      /* Variable: theta_o
                                        * Referenced by: '<S1>/Constant1'
                                        */
  real_T OnDelay_DelayType;            /* Mask Parameter: OnDelay_DelayType
                                        * Referenced by: '<S23>/Constant2'
                                        */
  real_T OnDelay_delay;                /* Mask Parameter: OnDelay_delay
                                        * Referenced by: '<S23>/Constant1'
                                        */
  real_T SampleandHold_ic;             /* Mask Parameter: SampleandHold_ic
                                        * Referenced by: '<S33>/IC=ic'
                                        */
  real_T SampleandHold_ic_n;           /* Mask Parameter: SampleandHold_ic_n
                                        * Referenced by: '<S41>/IC=ic'
                                        */
  real_T EdgeDetector_model;           /* Mask Parameter: EdgeDetector_model
                                        * Referenced by: '<S28>/Constant1'
                                        */
  real_T EdgeDetector_model_p;         /* Mask Parameter: EdgeDetector_model_p
                                        * Referenced by: '<S36>/Constant1'
                                        */
  boolean_T OnDelay_ic;                /* Mask Parameter: OnDelay_ic
                                        * Referenced by:
                                        *   '<S28>/Memory'
                                        *   '<S36>/Memory'
                                        */
  boolean_T SRFlipFlop3_initial_condition;
                                /* Mask Parameter: SRFlipFlop3_initial_condition
                                 * Referenced by: '<S42>/Memory'
                                 */
  boolean_T SRFlipFlop5_initial_condition;
                                /* Mask Parameter: SRFlipFlop5_initial_condition
                                 * Referenced by: '<S44>/Memory'
                                 */
  boolean_T SRFlipFlop6_initial_condition;
                                /* Mask Parameter: SRFlipFlop6_initial_condition
                                 * Referenced by: '<S45>/Memory'
                                 */
  boolean_T SRFlipFlop4_initial_condition;
                                /* Mask Parameter: SRFlipFlop4_initial_condition
                                 * Referenced by: '<S43>/Memory'
                                 */
  real_T MATLABSystem_SampleTime;      /* Expression: -1
                                        * Referenced by: '<S2>/MATLAB System'
                                        */
  real_T Out1_Y0;                      /* Expression: -1e6
                                        * Referenced by: '<S32>/Out1'
                                        */
  real_T posedge_Value[2];             /* Expression: [1 0]
                                        * Referenced by: '<S28>/pos. edge'
                                        */
  real_T negedge_Value[2];             /* Expression: [0 1]
                                        * Referenced by: '<S28>/neg. edge'
                                        */
  real_T eitheredge_Value[2];          /* Expression: [1 1]
                                        * Referenced by: '<S28>/either edge'
                                        */
  real_T Out1_Y0_n;                    /* Expression: -1e6
                                        * Referenced by: '<S40>/Out1'
                                        */
  real_T posedge_Value_d[2];           /* Expression: [1 0]
                                        * Referenced by: '<S36>/pos. edge'
                                        */
  real_T negedge_Value_c[2];           /* Expression: [0 1]
                                        * Referenced by: '<S36>/neg. edge'
                                        */
  real_T eitheredge_Value_m[2];        /* Expression: [1 1]
                                        * Referenced by: '<S36>/either edge'
                                        */
  real_T DigitalInput_SampleTime;      /* Expression: -1
                                        * Referenced by: '<S10>/Digital Input'
                                        */
  real_T DigitalInput1_SampleTime;     /* Expression: -1
                                        * Referenced by: '<S10>/Digital Input1'
                                        */
  real_T DigitalInput2_SampleTime;     /* Expression: -1
                                        * Referenced by: '<S10>/Digital Input2'
                                        */
  real_T DigitalInput3_SampleTime;     /* Expression: -1
                                        * Referenced by: '<S10>/Digital Input3'
                                        */
  real_T Integrator1_IC[3];            /* Expression: [12*pi/180 0 0]'
                                        * Referenced by: '<S12>/Integrator1'
                                        */
  real_T Gain_Gain[9];                 /* Expression: [0 1 0;0 0 1;0 0 0]
                                        * Referenced by: '<S12>/Gain'
                                        */
  real_T Integrator_IC;                /* Expression: 12*pi/180
                                        * Referenced by: '<S1>/Integrator'
                                        */
  real_T Gain2_Gain[3];                /* Expression: [Beta1 Beta2 Beta3]'
                                        * Referenced by: '<S12>/Gain2'
                                        */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S12>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S12>/Constant1'
                                        */
  real_T Multiply_Gain;                /* Expression: 10
                                        * Referenced by: '<Root>/Multiply'
                                        */
  real_T Gain1_Gain;                   /* Expression: pi/180
                                        * Referenced by: '<S4>/Gain1'
                                        */
  real_T Gain_Gain_p;                  /* Expression: (omga_c)^2
                                        * Referenced by: '<S11>/Gain'
                                        */
  real_T Constant_Value_l;             /* Expression: 1
                                        * Referenced by: '<S23>/Constant'
                                        */
  real_T Constant_Value_k;             /* Expression: 0
                                        * Referenced by: '<S9>/Constant'
                                        */
  real_T Gain1_Gain_h;                 /* Expression: pi/180
                                        * Referenced by: '<S15>/Gain1'
                                        */
  real_T Integrator1_IC_o;             /* Expression: 0
                                        * Referenced by: '<S1>/Integrator1'
                                        */
  real_T Gain_Gain_h;                  /* Expression: 180/pi
                                        * Referenced by: '<S46>/Gain'
                                        */
  real_T Gain_Gain_i;                  /* Expression: -1
                                        * Referenced by: '<S6>/Gain'
                                        */
  real_T Gain1_Gain_c;                 /* Expression: -1
                                        * Referenced by: '<S6>/Gain1'
                                        */
  real_T Gain2_Gain_f;                 /* Expression: 1
                                        * Referenced by: '<S6>/Gain2'
                                        */
  real_T Gain_Gain_c;                  /* Expression: 180/pi
                                        * Referenced by: '<S16>/Gain'
                                        */
  boolean_T OUT_Y0;                    /* Computed Parameter: OUT_Y0
                                        * Referenced by: '<S24>/OUT'
                                        */
  boolean_T OUT_Y0_a;                  /* Computed Parameter: OUT_Y0_a
                                        * Referenced by: '<S25>/OUT'
                                        */
  boolean_T Logic_table[16];           /* Computed Parameter: Logic_table
                                        * Referenced by: '<S42>/Logic'
                                        */
  boolean_T Logic_table_c[16];         /* Computed Parameter: Logic_table_c
                                        * Referenced by: '<S44>/Logic'
                                        */
  boolean_T Logic_table_k[16];         /* Computed Parameter: Logic_table_k
                                        * Referenced by: '<S45>/Logic'
                                        */
  boolean_T Logic_table_p[16];         /* Computed Parameter: Logic_table_p
                                        * Referenced by: '<S43>/Logic'
                                        */
  uint8_T Gain_Gain_j;                 /* Computed Parameter: Gain_Gain_j
                                        * Referenced by: '<S9>/Gain'
                                        */
  P_POSITIVEEdge_CONTROL_SYSTEM_T POSITIVEEdge_h;/* '<S36>/POSITIVE Edge' */
  P_NEGATIVEEdge_CONTROL_SYSTEM_T NEGATIVEEdge_e;/* '<S36>/NEGATIVE Edge' */
  P_POSITIVEEdge_CONTROL_SYSTEM_T POSITIVEEdge;/* '<S28>/POSITIVE Edge' */
  P_NEGATIVEEdge_CONTROL_SYSTEM_T NEGATIVEEdge;/* '<S28>/NEGATIVE Edge' */
};

/* Real-time Model Data Structure */
struct tag_RTM_CONTROL_SYSTEM_V2_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;
  X_CONTROL_SYSTEM_V2_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  XDis_CONTROL_SYSTEM_V2_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[5];
  real_T odeF[3][5];
  ODE3_IntgData intgData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    time_T tStart;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (default storage) */
extern P_CONTROL_SYSTEM_V2_T CONTROL_SYSTEM_V2_P;

/* Block signals (default storage) */
extern B_CONTROL_SYSTEM_V2_T CONTROL_SYSTEM_V2_B;

/* Continuous states (default storage) */
extern X_CONTROL_SYSTEM_V2_T CONTROL_SYSTEM_V2_X;

/* Disabled states (default storage) */
extern XDis_CONTROL_SYSTEM_V2_T CONTROL_SYSTEM_V2_XDis;

/* Block states (default storage) */
extern DW_CONTROL_SYSTEM_V2_T CONTROL_SYSTEM_V2_DW;

/* Zero-crossing (trigger) state */
extern PrevZCX_CONTROL_SYSTEM_V2_T CONTROL_SYSTEM_V2_PrevZCX;

/* Model entry point functions */
extern void CONTROL_SYSTEM_V2_initialize(void);
extern void CONTROL_SYSTEM_V2_step(void);
extern void CONTROL_SYSTEM_V2_terminate(void);

/* Real-time Model object */
extern RT_MODEL_CONTROL_SYSTEM_V2_T *const CONTROL_SYSTEM_V2_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S6>/Constant' : Unused code path elimination
 * Block '<S6>/Constant1' : Unused code path elimination
 * Block '<S6>/Constant2' : Unused code path elimination
 * Block '<S29>/Constant' : Unused code path elimination
 * Block '<S29>/Relational Operator' : Unused code path elimination
 * Block '<S29>/Sum' : Unused code path elimination
 * Block '<S37>/Constant' : Unused code path elimination
 * Block '<S37>/Relational Operator' : Unused code path elimination
 * Block '<S37>/Sum' : Unused code path elimination
 * Block '<Root>/If Condition1' : Unused code path elimination
 * Block '<S23>/Data Type Conversion1' : Eliminate redundant data type conversion
 * Block '<S28>/Data Type Conversion2' : Eliminate redundant data type conversion
 * Block '<S33>/Data Type Conversion' : Eliminate redundant data type conversion
 * Block '<S36>/Data Type Conversion2' : Eliminate redundant data type conversion
 * Block '<S41>/Data Type Conversion' : Eliminate redundant data type conversion
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'CONTROL_SYSTEM_V2'
 * '<S1>'   : 'CONTROL_SYSTEM_V2/AETV_system'
 * '<S2>'   : 'CONTROL_SYSTEM_V2/Analog Signal1'
 * '<S3>'   : 'CONTROL_SYSTEM_V2/Button Control1'
 * '<S4>'   : 'CONTROL_SYSTEM_V2/Degrees to Radians1'
 * '<S5>'   : 'CONTROL_SYSTEM_V2/Desired signals_Sinewave'
 * '<S6>'   : 'CONTROL_SYSTEM_V2/Desired_Reference_step_input'
 * '<S7>'   : 'CONTROL_SYSTEM_V2/FP_Input Range Conversion1'
 * '<S8>'   : 'CONTROL_SYSTEM_V2/Foot Pedal Calibration1'
 * '<S9>'   : 'CONTROL_SYSTEM_V2/H-Bridge Setting1'
 * '<S10>'  : 'CONTROL_SYSTEM_V2/Latching1'
 * '<S11>'  : 'CONTROL_SYSTEM_V2/SFBC_Controller'
 * '<S12>'  : 'CONTROL_SYSTEM_V2/Subsystem5'
 * '<S13>'  : 'CONTROL_SYSTEM_V2/TB_Feedbakc Range Conversion1'
 * '<S14>'  : 'CONTROL_SYSTEM_V2/Throttle Body Callibration1'
 * '<S15>'  : 'CONTROL_SYSTEM_V2/AETV_system/Degrees to Radians'
 * '<S16>'  : 'CONTROL_SYSTEM_V2/Desired_Reference_step_input/Radians to Degrees2'
 * '<S17>'  : 'CONTROL_SYSTEM_V2/Desired_Reference_step_input/Signal Builder'
 * '<S18>'  : 'CONTROL_SYSTEM_V2/Desired_Reference_step_input/Signal Builder1'
 * '<S19>'  : 'CONTROL_SYSTEM_V2/Desired_Reference_step_input/Signal Builder2'
 * '<S20>'  : 'CONTROL_SYSTEM_V2/Desired_Reference_step_input/Signal Builder3'
 * '<S21>'  : 'CONTROL_SYSTEM_V2/Desired_Reference_step_input/Signal Builder4'
 * '<S22>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay'
 * '<S23>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model'
 * '<S24>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/OFF Delay'
 * '<S25>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/ON Delay'
 * '<S26>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/OFF Delay/Edge Detector'
 * '<S27>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/OFF Delay/Sample and Hold'
 * '<S28>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/OFF Delay/Edge Detector/Model'
 * '<S29>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/OFF Delay/Edge Detector/Model/Internal dirac generator'
 * '<S30>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/OFF Delay/Edge Detector/Model/NEGATIVE Edge'
 * '<S31>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/OFF Delay/Edge Detector/Model/POSITIVE Edge'
 * '<S32>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/OFF Delay/Edge Detector/Model/Internal dirac generator/Triggered Subsystem'
 * '<S33>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/OFF Delay/Sample and Hold/Model'
 * '<S34>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/ON Delay/Edge Detector'
 * '<S35>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/ON Delay/Sample and Hold'
 * '<S36>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/ON Delay/Edge Detector/Model'
 * '<S37>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/ON Delay/Edge Detector/Model/Internal dirac generator'
 * '<S38>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/ON Delay/Edge Detector/Model/NEGATIVE Edge'
 * '<S39>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/ON Delay/Edge Detector/Model/POSITIVE Edge'
 * '<S40>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/ON Delay/Edge Detector/Model/Internal dirac generator/Triggered Subsystem'
 * '<S41>'  : 'CONTROL_SYSTEM_V2/H-Bridge Setting1/On Delay/Model/ON Delay/Sample and Hold/Model'
 * '<S42>'  : 'CONTROL_SYSTEM_V2/Latching1/S-R Flip-Flop3'
 * '<S43>'  : 'CONTROL_SYSTEM_V2/Latching1/S-R Flip-Flop4'
 * '<S44>'  : 'CONTROL_SYSTEM_V2/Latching1/S-R Flip-Flop5'
 * '<S45>'  : 'CONTROL_SYSTEM_V2/Latching1/S-R Flip-Flop6'
 * '<S46>'  : 'CONTROL_SYSTEM_V2/SFBC_Controller/Radians to Degrees4'
 */
#endif                                 /* CONTROL_SYSTEM_V2_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
